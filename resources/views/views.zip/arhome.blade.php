<!DOCTYPE html>



<!-- Mirrored from jituchauhan.com/borrow/borrow/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 20 Dec 2016 09:01:30 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="language" content="Arabic">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="Alboraq is certified translation services online , we provides certified german translation services , certified french translation services , certified translation services birth certificate and other services, our website translation services cost is not high ,our online language translation services is the most professional translation services in egypt .">
    <meta name="keywords" content="Financial Website Template, Bootstrap Template, Loan Product, Personal Loan">
    <title>افضل خدمات الترجمة عبر الانترنت | ترجمة مصدقة عبر انترنت | خدمات الترجمة عبر الانترنت</title>
    <!-- Bootstrap -->
    <link href="{!!asset('css/bootstrap.min.css')!!}" rel="stylesheet">
    <link href="{!!asset('css/style.css')!!}" rel="stylesheet">
    <link href="{!!asset('css/font-awesome.min.css')!!}" rel="stylesheet">
    <link href="{!!asset('css/fontello.css')!!}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{!!asset('css/animsition.min.css')!!}">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700|Merriweather:300,300i,400,400i,700,700i" rel="stylesheet">
    <!-- owl Carousel Css -->
    <link href="{!!asset('css/owl.carousel.css')!!}" rel="stylesheet">
    <link href="{!!asset('css/owl.theme.css')!!}" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<style type="text/css">
    

    .c{

        font-size: 120%
    }
    .al{

        text-align: right;
    }

    .wi{

        font-weight: 16px
    }
</style>
<body class="animsition">
    <div class="collapse searchbar" id="searchbar">
        <div class="search-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search for...">
                            <span class="input-group-btn">
            <button class="btn btn-default" type="button">Go!</button>
            </span> </div>
                        <!-- /input-group -->
                    </div>
                    <!-- /.col-lg-6 -->
                </div>
            </div>
        </div>
    </div>
 <div class="top-bar">
        <!-- top-bar -->
        <div class="container">
            <div class="row" >
                <div class="col-md-4 hidden-xs hidden-sm">
                    <p class="mail-text" style="font-size:15px">مرحبا بكم في شركة البراق للترجمة المعتمدة</p>
                </div>
                <div class="col-md-8 col-sm-12 text-right col-xs-12"  style="font-size:13px">
                    <div class="top-nav"> <span class="top-text hidden-xs"><a href="{{url('arabic-about-contact-us')}}">لمعرفة مكان الشركة</a> </span> <span class="top-text"><a href="{{url('/')}}">English</a></span> <span class="top-text"><a href="{{url('/arabic')}}">عربي</a></span> </div>
                </div>
            </div>
        </div>
    </div>

    <style type="text/css">
.wi{


    font-weight: 500px
}
.c{


    font-size:19px 
}

.al{

    text-align: right;
}
</style>
    <!-- /.top-bar -->
    <div class="header">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-sm-12 col-xs-6" style="padding-left: 10px">
                    <!-- logo -->
                    <div class="logo"  >
                        <a href="{{url('/arabic')}}"><img   src="{!!asset('images/logo2.png')!!}" alt="Borrow - Loan Company Website Template" style="background-color: black" ></a>
                    </div>
                </div>
                <!-- logo -->
                 <div class="col-md-9 col-sm-12 col-xs-12" style="width:80%;float: right;margin-top:1px;hight:60px;margin-right: 2px">
                    <div id="navigation" >
                        <!-- navigation start-->
                        <ul >
                             <li><a style="font-size:19px" href="{{url('arabic-our-customers')}}" title="Contact us" class="animsition-link c">عملائنا</a></li>
                             <li>   <a style="font-size:19px" href="{{url('arabic-translator-jobs')}}" title="Personal Loan" class="animsition-link">انضم الينا</a></li>
                              <li><a style="font-size:19px" href="{{url('arabic-certifications')}}" title="Contact us" class="animsition-link">الاعتمادات</a></li>
                            <li><a style="font-size:19px" href="{{url('arabic-online-translation')}}" class="animsition-link">للترجمة أون لين</a>
                                        <!--<ul>
                                            <li><a href="shortcodes-tables.html" title="Table" class="animsition-link">Table</a></li>
                                            <li><a href="shortcodes-tabs.html" title="Tab" class="animsition-link">Tab</a></li>
                                            <li><a href="shortcodes-accordion.html" title="Accordion" class="animsition-link">Accordion</a></li>
                                            <li><a href="shortcodes-alert.html" title="Alert" class="animsition-link">Alert</a></li>
                                            <li><a href="shortcodes-button.html" title="Button" class="animsition-link">Button</a></li>
                                            <li><a href="shortcodes-column.html" title="Column" class="animsition-link">Column</a></li>
                                        </ul>-->
                                   
                            </li>
                             <li><a style="font-size:19px" href="{{url('languages')}}" class="animsition-link">اللغات</a>
                               <!-- <ul>
                                    <li><a href="compare-loan.html" title="Compare Loan" class="animsition-link">Compare Loan</a></li>
                                    <li><a href="loan-calculator.html" title="Loan Calculator" class="animsition-link">Loan Calculator</a></li>
                                    <li><a href="landing-page-car-loan.html" title="Loan Calculator" class="animsition-link">Car Loan 
                                     <small class="highlight">Landing Page</small>

                                     </a></li>
                                    <li><a href="landing-page-home-loan.html" title="Loan Calculator" class="animsition-link">Home Loan 
                                     <small class="highlight">Landing Page</small>

                                     </a></li>
                                    <li><a href="loan-calculator.html" title="Loan Calculator" class="animsition-link">Loan Calculator</a></li>
                                    <li><a href="faq.html" title="Faq" class="animsition-link">Faq page</a></li>
                                    <li><a href="testimonial.html" title="Testimonial" class="animsition-link">Testimonial</a></li>
                                    <li><a href="error.html" title="404 Error" class="animsition-link">404 Error</a></li>
                                    <li><a href="gallery-filter-2.html" class="animsition-link">Gallery</a>
                                        <ul>
                                            <li><a href="gallery-filter-2.html" title="Filterable Gallery 2 column" class="animsition-link">Filterable Gallery 2 column</a></li>
                                            <li><a href="gallery-filter-3.html" title="Filterable Gallery 3 column" class="animsition-link">Filterable Gallery 3 column</a></li>
                                            <li><a href="gallery-masonry.html" title="Masonry Gallery" class="animsition-link">Masonry Gallery</a></li>
                                            <li><a href="gallery-zoom.html" title="Zoom Gallery" class="animsition-link">Zoom Gallery</a></li>
                                        </ul>-->
                                    </li>
                             <li><a style="font-size:19px"  href="{{url('arabic-document-type-we-translate')}}" class="animsition-link">الوثائق </a>
                               <!-- <ul>
                                    <li><a href="blog-listing.html" title="Blog Listing" class="animsition-link">Blog Listing</a></li>
                                    <li><a href="blog-single.html" title="Blog Single" class="animsition-link">Blog Single</a></li>
                                    <li><a href="blog-two-column.html" title="Blog Two Column" class="animsition-link">Blog Two Column</a></li>
                                    <li><a href="blog-three-column.html" title="Blog Three Column" class="animsition-link">Blog Three Column</a></li>
                                </ul>-->
                            </li>

                            <li><a style="font-size:19px" class="animsition-link">خدمتنا</a>
                                <ul>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-document-proofreading-editing')}}" title="About us" class="animsition-link">مراجعة و تصحيح الوثائق</a></li>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-document-translation')}}" title="Team" class="animsition-link">ترجمة الوثائق</a></li>

<li><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-website-translation')}}" title="Team" class="animsition-link">ترجمة المواقع الألكترونية</a></li>
                      
                                    <li><a  style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-simultaneous-interpretation')}}" title="Team" class="animsition-link">ترجمة فورية</a></li>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-document-transcription')}}" title="Team" class="animsition-link">نسخ</a></li>
                                    <li style="height: 70px" ><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-video-audio-interpretation')}}" title="Team" class="animsition-link">ترجمة الفيديو و الملفات الصوتية</a></li>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-localization')}}" title="Team" class="animsition-link">التعريب</a></li>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-content-development')}}" title="Team" class="animsition-link">تطوير و كتابة المحتوى</a></li>
                                </ul>
                            </li>
                                 <li><a style="font-size:19px;text-align: right" class="animsition-link">عن</a>
                                <ul>
                                    <li><a style="font-size:19px;text-align: right"  href="{{url('arabic-about-who-is-Alboraq')}}" title="Loan Image Listing" class="animsition-link">تعرف الى البراق</a></li>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-about-our-advantages')}}" title="Loan Icon Listing" class="animsition-link">مميزاتنا</a></li>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-about-our-team')}}" title="Car Loan" class="animsition-link">خبراء الترجمة</a></li>
                                   
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-about-contact-us')}}" title="Home Loan" class="animsition-link">للتواصل معنا</a></li>
                                   
                                </ul>
                            </li>
                            <li class="active"><a style="font-size:19px" href="{{url('/arabic')}}" class="animsition-link">الصفحة الرئيسية</a>
                               <!-- <ul>
                                    <li><a href="index.html" title="Home page 1" class="animsition-link">Home page 1</a></li>
                                    <li><a href="index-1.html" title="Home page 2" class="animsition-link">Home page 2</a></li>
                                    <li><a href="index-2.html" title="Home page 3" class="animsition-link">Home page 3</a></li>
                                </ul>-->
                            </li>
                       
                         
                           
                                    
                          
                        


                            
                             





                        </ul>
                    </div>
                    <!-- /.navigation start-->
                </div>
                <!--
                <div class="col-md-1 hidden-sm">
          
                    <div class="search-nav"> <a class="search-btn" role="button" data-toggle="collapse" href="#searchbar" aria-expanded="false"><i class="fa fa-search"></i></a> </div>
                </div>-->
                <!-- /.search start-->
            </div>
        </div>
    </div>

<!--    <div class="col-md-1 hidden-sm">
                    
                    <div class="search-nav"> <a class="search-btn" role="button" data-toggle="collapse" href="#searchbar" aria-expanded="false"><i class="fa fa-search"></i></a> </div>
                </div> -->
                <!-- /.search start-->
            </div>
        </div>
    </div>














@if(Session::has('message'))

<script type="text/javascript">
    alert("{{Session::get('message')}}")

</script>
@endif
 <div class="slider" id="slider">
        <!-- slider -->

   
        <div>
            <div class="slider-img"><img src="images/slider-3.jpg" alt="Borrow - Loan Company Website Template" class="">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                            <div class="slider-captions">
                                <!-- slider-captions -->
                                <h1 class="slider-title">نضمن لك الدقة<strong class="text-highlight">  %100</strong></h1>
                                <p class="slider-text hidden-xs">نحن نقدم لك خدمة  ممتازة لترجمة جميع انواع الوثائق لأغراض مختلفة
                                    <br> </p>
                                <a href="{{url('arabic-online-translation')}}" class="btn btn-default hidden-xs c">أرسل ترجمتك عبر الأنترنت</a> </div>
                            <!-- /.slider-captions -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<!--
    <div class="rate-table">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="rate-counter-block">
                        <div class="icon rate-icon  "> <img src="images/mortgage.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-1x"></div>
                        <div class="rate-box">
                            <h1 class="loan-rate">3.74%</h1>
                            <small class="rate-title">Home Loans</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="rate-counter-block">
                        <div class="icon rate-icon  "> <img src="images/loan.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-1x"></div>
                        <div class="rate-box">
                            <h1 class="loan-rate">8.96%</h1>
                            <small class="rate-title">Personal Loans</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="rate-counter-block">
                        <div class="icon rate-icon  "> <img src="images/car.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-1x"></div>
                        <div class="rate-box">
                            <h1 class="loan-rate">6.70%</h1>
                            <small class="rate-title">Car Loans</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-6">
                    <div class="rate-counter-block">
                        <div class="icon rate-icon  "> <img src="images/credit-card.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-1x"></div>
                        <div class="rate-box">
                            <h1 class="loan-rate">9.00%</h1>
                            <small class="rate-title">Credit card</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
-->
        <div class="section-space80">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <i class="icon-users icon-2x icon-default"></i>
                    <h1 class="wi" ><b>لماذا تختار البراق للترجمة ؟</b> </h1>
                    <p class="c"> شركة البراق معتمدة فى مجال الترجمة  الموجودة فى مصر(<a href="{{url('arabic-about-contact-us')}}">موقع الشركة</a>)يتيح ترجمة جميع اللغات الاجنبية  </p>
                    <a href="{{url('arabic-online-translation')}}" class="btn btn-primary c">أرسل ترجمتك عبر الأنترنت</a>
                </div>
                <div class="col-md-offset-1 col-md-7 col-xs-12 col-sm-12">
                    <div class="st-accordion ">
                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingOne">
                                    <h4 class="panel-title al" style="font-size: 22px"> <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"><b >تريد التعرف على شركة البراق ؟</b></a> </h4>
  <b></b>                              </div>
                                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                    <div class="panael-body c al"> البراق هي شركة ترجمة معتمدة في مصر<a href="{{url('arabic-about-contact-us')}}">لمشاهدة موقع الشركة</a> يتيح لجميع خدمة ترجمة للغات الاجنبية عالية الجودة والدقة فى الترجمة, الألتزام بمواعيد التسليم  , تأسست اليراق في عام 2010 , نضمن لك خدمة 24/7 تتضمن الأجازات الرسمية <a href="{{url('arabic-about-who-is-Alboraq')}}">تعريف كامل لشركة البراق</a>.</div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading al" role="tab" id="headingTwo">
                                    <h4 class="panel-title"  style="font-size: 22px"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"><b>من يقوم بترجمة ملفاتك ؟</b>   </a> </h4>
                                </div>
                                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                    <div class="panel-body c al">البراق تضم أمهر المترجمين  الحاصلين على شهادات الخبراة من مراكز معتمدة , مترجمينا خبرة  من 5-10 في الترجمة في مختلف المجالات ,و بالطبع يقود خبرائنا أحد أمهر المنفذين التنفذيين في مصر ,خبرة 10 سنوات في مجال الترجمة و قاد عدة شركات ترجمة كبرى في مصر <a href="{{url('arabic-about-our-team')}}">لمعرفة خبرائنا في الترجمة</a></div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading al" role="tab" id="headingThree">
                                    <h4 class="panel-title"  style="font-size: 22px"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree"> <b>نوع الخدمات التى نقدمها ؟</b> </a> </h4>
                                </div>
                                <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                    <div class="panel-body c al">لدينا خدمات كثيرة في الترجمة لمختلف أنواع الستندات<a href="{{url('arabic-document-type-we-translate')}}"> لمعرفة أنواع المستندات التي نترجمها </a>, مراجعة الوثائق <a href="{{url('arabic-translation-service-document-proofreading-editing')}}">لمعرفة المزيد عن مراجعة الوثائق</a>,الترجمة الفورية <a href="{{url('arabic-translation-service-simultaneous-interpretation')}}" > لمعرفة المزيد عن ترجمتنا الفورية</a>, نسخ الملفات <a href="{{url('arabic-translation-service-document-transcription')}}">لمزيد من المعلومات عن نسخ الملفات</a>, <a href="{{url('arabic-translation-service-video-audio-interpretation')}}">لمزيد من ترجمة فيديو و ملفات صوتية </a>, التعريب <a href="{{url('arabic-translation-service-localization')}}">لمزيد من المعلومات عن التعريب</a>
                                     </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingFour">
                                    <h4 class="panel-title al"  style="font-size: 22px"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">  <b>هل حصلت البراق على شهادات ؟</b></a> </h4>
                                </div>
                                <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                                    <div class="panel-body c al"> البراق تركة ترجمة معتمدة  حاصلة على شهادة الجمعية المصرية للمترجمين <a href="{{url('arabic-certifications')}}"> لمشاهدة شهادتنا </a>. </div>
                                </div>

                               
                            </div>


                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingFour">
                                    <h4 class="panel-title al"  style="font-size: 22px"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseu" aria-expanded="false" aria-controls="collapseFour"> <b>ماذا عن أسعار الترجمة ؟</b> </a> </h4>
                                </div>
                                <div id="collapseu" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                                    <div class="panel-body c  al">لدينا عروض مميزة لعملائنا, ستدفعون لاول نسخه و النسخة الثانية بنصف السعر و بقية النسخ مجانا </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


     <div class="section-space80">
        <div class="container">
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-12 col-xs-12">
                    <div class="mb60 text-center section-title">
                        <!-- section title start-->
                        <h1 class="wi">أنواع الملفات التي نترجمها</h1>
                        <p class="c">نحن نقوم بترجمة جميع أنواع الملفات في مختلف المجالات<a href="{{url('arabic-document-type-we-translate')}}"> لمعرفة أنواع الملفات التي نترجمها</a></p>
                    </div>
                    <!-- /.section title start-->
                </div>
            </div>
            <div class="row">
                <div class="service" id="service">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="bg-white pinside40 service-block outline mb30">
                            <div class="icon mb40"> <img src="images/loan.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-2x"> </div>
                            <h2><a href="#" class="title">ميكروسفت ورد</a></h2>
                            <h2><a href="#" class="title">PDF</a></h2>
                            <h2><a href="#" class="title">عقود</a></h2>
                             
                            <p></p>
                           <!-- <a href="#" class="btn-link">Read More</a> --></div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="bg-white pinside40 service-block outline mb30">
                            <div class="icon mb40"> <img src="images/mortgage.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-2x"></div>
                            <h2><a href="#" class="title">كتب</a></h2>
                            <h2><a href="#" class="title">بطاقات العمل</a></h2>
                             <h2><a href="#" class="title"> شهادات</a></h2>
                             </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="bg-white pinside40 service-block outline mb30">
                            <div class="icon mb40"> <img src="images/piggy-bank.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-2x"></div>
                            <h2><a href="#" class="title">أتفاقيات</a></h2>
                            <h2><a href="#" class="title">رسائل الشركات</a></h2>
                            <h2><a href="#" class="title">قوامسس</a></h2></div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">

                        <div class="bg-white pinside40 service-block outline mb30">
                            <div class="icon mb40"> <img src="images/loan.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-2x"></div>
                            <h2><a href="#" class="title">بريد الكتروني و رسائل ورقية</a></h2> 
                            <h2><a href="#" class="title">البيانات المالية</a></h2>
                            <h2><a href="#" class="title">ملفات فلاش</a></h2>
                             </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="bg-white pinside40 service-block outline mb30">
                            <div class="icon mb40"> <img src="images/car.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-2x"></div>
                            <h2><a href="#" class="title">مواقع</a></h2>
                              <h2><a href="#" class="title">محاضرات</a></h2>
                                <h2><a href="#" class="title">ملفات علمية</a></h2>

                              </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-white section-space80">
        <div class="container">
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-xs-12">
                    <div class="mb100 text-center section-title">
                        <!-- section title start-->
                        <h1 class="wi">نحن نضمن لك الكفائة و الجودة</h1>
                        <p class="c">نحن شركة ترجمة معتمدة نقدم لعملائنا ترجمة بجودة عالية </p>
                    </div>
                    <!-- /.section title start-->
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="bg-white pinside40 number-block outline mb60 bg-boxshadow">
                        <div class="circle"><span class="number">1</span></div>
                        <h3 class="number-title">السرعة</h3>
                        <p class="c">نحن نترجم ملفاتك في أقل وقت ممكن بأحترافية شديدة دون أخطاء</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="bg-white pinside40 number-block outline mb60 bg-boxshadow">
                        <div class="circle"><span class="number">2</span></div>
                        <h3 class="number-title">الدقة</h3>
                        <p class="c">خبرائنا في الترجمة يقومن بترجمة وثائقك باحترافية شديدة في أقل  وقت ممكن  </p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="bg-white pinside40 number-block outline mb60 bg-boxshadow">
                        <div class="circle"><span class="number">3</span></div>
                        <h3 class="number-title">أقل الأسعار</h3>
                        <p class="c">ستحصل على ترجمة معتمدة بأقل الأسعار </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-offset-2 col-sm-8 text-center"> <a href="{{url('arabic-about-contact-us')}}" class="btn btn-default">زور شركتنا للحصول على ترجمة</a> </div>
            </div>
        </div>
    </div>
    <div class="section-space80">
        <div class="container">
            <div class="row">
                <div class="col-md-offset-2 col-md-8">
                    <div class="mb60 text-center section-title">
                        <!-- section title start-->
                        <h1 >رؤينا و هدفنا</h1>
                        <p class="c"> لدينا رؤية و هدفنا الخاص بنا و نحن نريد أن نكون على قمة شكات الترجمة في الشرق الأوسط </p>
                    </div>
                    <!-- /.section title start-->
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="bg-white bg-boxshadow">
                        <div class="row">
                            <div class="col-md-4 col-sm-6 nopadding col-xs-12">
                                <div class="bg-white pinside60 number-block outline" style="height: 400px">
                                    <div class="mb20"><i class="icon-command  icon-4x icon-primary"></i></div>
                                    <h3 class="wi">رؤيتنا</h3>
                                    <p class="c"> نحن نريد أن نكون على قمة شكات الترجمة في الشرق الأوسط</p>
                                     </div>
                            </div>
                            <div class="col-md-4 col-sm-6 nopadding col-xs-12">
                                <div class="bg-white pinside60 number-block outline" style="height: 400px">
                                    <div class="mb20"><i class="icon-cup  icon-4x icon-primary"></i></div>
                                    <h3 class="wi">هدفنا</h3>
                                    <p class="c"> إنشاء قاعدة بيانات من اللغويين والمترجمين الذين ليس لديهم خبرة فقط في مجال الترجمة ومتخصصين في مجالات مختلفة مثل: الترجمة القانونية  االاقتصادية  الطبية  الفنية.... ولكن أيضا يمكن الاعتماد عليهم في الوفاء بالتزاماتهم  </p>
                                   </div>
                            </div>
                            <div class="col-md-4 col-sm-12 nopadding col-xs-12" >
                                <div class="bg-white pinside60 number-block outline" style="height: 400px">
                                    <div class="mb20"><i class="icon-calculator  icon-4x icon-primary"></i></div>
                                    <h3 class="wi">أنجازاتنا</h3>
                                    <p class="c"> لقد حققنا أنجازات عديدة و قريبا سنصبح على قمة الترجمة في الشرق الأوسط</p>
                                     </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-default section-space80">
        <div class="container">
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-offset-2 col-sm-8">
                    <div class="mb60 text-center section-title">
                        <!-- section title start-->
                        <h1 class="title-white">رأى عملائنا</h1>
                        <p> اليك رأي عملائنا في خدمتنا </p>
                    </div>
                    <!-- /.section title start-->
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-4 clearfix col-xs-12">
                    <div class="testimonial-block mb30">
                        <div class="bg-white pinside30 mb20" style="text-align: right;">
                            <p class="testimonial-text" class="wi c al"> شكرا لتفهمكم ومواصلة العمل الجيد. إذا كنتم فى أي وقت بحاجة إلى مرجعية دولية لمشروع ما، سأكون سعيدا أن أنقل تجربتي مع شركتكم</p>
                        </div>
                        <div class="testimonial-autor-box">
                            <div class="testimonial-img pull-left"><img src="images/download.jpg" alt="" style="width: 60px;height: 65px"> </div>
                            <div class="testimonial-autor pull-left">
                                <h4 class="testimonial-name c">السيد ديفيد تيدول</h4>
                                <span class="testimonial-meta c">بي جي أمريكا</span> </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 clearfix col-xs-12">
                    <div class="testimonial-block mb30">
                        <div class="bg-white pinside30 mb20">
                            <p class="testimonial-text c wi al">  أداء ممتاز على ترجمة فورية </p>
                        </div>
                        <div class="testimonial-autor-box">
                            <div class="testimonial-img pull-left"> <img src="images/download.jpg" alt="" style="width: 60px;height: 65px"></div>
                            <div class="testimonial-autor pull-left">
                                <h4 class="testimonial-name c">السيد بول ماكدونالد</h4>
                                <span class="testimonial-meta c">شركة ستينا</span> </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 clearfix col-xs-12">
                    <div class="testimonial-block mb30">
                        <div class="bg-white pinside30 mb20">
                            <p class="testimonial-text wi c al" >  أداء ممتاز على ترجمة فورية </p>
                        </div>
                        <div class="testimonial-autor-box">
                            <div class="testimonial-img pull-left"> <img src="images/download.jpg" alt="" style="width: 60px;height: 65px"> </div>
                            <div class="testimonial-autor pull-left">
                                <h4 class="testimonial-name c">السيد مايك جورج</h4>
                                <span class="testimonial-meta c">مدير الصحة والسلامة والبيئة بشركة هيس</span> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section-space80 bg-white">
        <div class="container">
            <div class="row">
                <div class="col-md-offset-2 col-md-8 col-sm-offset-2 col-sm-8">
                    <div class="mb60 text-center section-title">
                        <!-- section title-->
                        <h1 class="wi">خدمات سريعة </h1>
                        <p class="c">أختر واحد من الخدمات السريعة</p>
                    </div>
                    <!-- /.section title-->
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="bg-white bg-boxshadow pinside40 outline text-center mb30">
                        <div class="mb40"><i class="icon-calendar-3 icon-2x icon-default"></i></div>
                        <h2 class="capital-title c">أرسل ترجمتك الينا عبر الأنترنت</h2>
                        <p class="c"> اذا كان وقتك ديق و لاتستطيع زيارة شركتنا يمكنك أرسال الملف الذي ترغب في ترجمتة عن طريف الأنترنت  </p>
                        <a href="{{url('arabic-online-translation')}}" class="btn-link">أرسل ملفك لنقوم بترجمته</a> </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="bg-white bg-boxshadow pinside40 outline text-center mb30">
                        <div class="mb40"><i class="icon-phone-call icon-2x icon-default"></i></div>
                        <h2 class="capital-title c">لمزيد من المعلومات يمكنك الأتصال بنا</h2>
                        <h1 class="text-big ">202 22685650 </h1>

                        <p>alboraq@alboraq.com.eg</p>
                        <a href="{{url('arabic-about-contact-us')}}" class="btn-link c">تواصل معنا</a> </div>
                </div>
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="bg-white bg-boxshadow pinside40 outline text-center mb30">
                        <div class="mb40"> <i class="icon-users icon-2x icon-default"></i></div>
                        <h2 class="capital-title c">يمكنك أرسال سيرتك الذاتية لتصبح أحد مترجمينا </h2>
                        <p class="c">اذا كنت ترغب في العمل لدوام كامل أو من البيت يمكنك ملأ الأستمارة و سنقوم بالتواصل معك  </p>
                        <a href="{{url('arabic-translator-jobs')}}" class="btn-link c">لأرسال السيرة الذاتية</a> </div>
                </div>
            </div>
        </div>
    </div>











    <div class="footer section-space80">
        <!-- footer -->
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="footer-logo">
                        <!-- Footer Logo -->
                        <img src="{!!asset('images/logo2.png')!!}" alt="Borrow - Loan Company Website Templates" style="width: 300px;height: 130px"> </div>
                    <!-- /.Footer Logo -->
                </div>
                <div class="col-md-8 col-sm-8 col-xs-12">
                    <div class="col-md-5">
                        <h3 class="newsletter-title"></h3>
                    </div>
                    <div class="col-md-7">
                       
                        <!-- /.Newsletter Form -->
                    </div>
                    <!-- /.col-lg-6 -->
                </div>
            </div>
            <hr class="dark-line">
            <div class="row">
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="widget-text mt40">
                        <!-- widget text -->
                        <p>شركتنا تضمن لك ترجمة معتمدة بأحترافية و دقة و في نفس الوقت بأقل الأسعار</p>
                        <div class="row">
                            <div class="col-md-6 col-xs-6">
                                <p class="address-text"><span><i class="icon-placeholder-3 icon-1x"></i> </span>22 شارع خالد بن الوليد-شيراتون - الدور الثاني - شقة 22 -القاهرة-مصر</p>
                            </div>
                            <div class="col-md-6 col-xs-6">
                                <p class="call-text"><span><i class="icon-phone-call icon-1x"></i></span>+202 22685650</p>


                                <p class="call-text"><span><i class="icon-phone-call icon-1x"></i></span>+2 010 69977924</p>

                                  <p class="call-text"><span><i class=""></i></span>alboraq@alboraq.com.eg</p>
                            </div>
                        </div>
                    </div>
                    <!-- /.widget text -->
                </div>
                <div class="col-md-2 col-sm-4 col-xs-6">
                    <div class="widget-footer mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                           
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
                <div class="col-md-2 col-sm-4 col-xs-6">
                    <div class="widget-footer mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                            
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
                <div class="col-md-2 col-sm-4 col-xs-12">
                    <div class="widget-social mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                            <li><a href="https://www.facebook.com/al.boraq.5?ref=br_rs"><i class="fa fa-facebook"></i>Facebook</a></li>
                            <li><a href="https://plus.google.com/u/0/111389319385238976171"><i class="fa fa-google-plus"></i>Google Plus</a></li>
                            <li><a href="https://twitter.com/AlBoraq_ABTS"><i class="fa fa-twitter"></i>Twitter</a></li>
                            <li><a href="https://www.linkedin.com/in/al-boraq-translation-services-1a235658"><i class="fa fa-linkedin"></i>Linked In</a></li>
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
            </div>
        </div>
    </div>
    <!-- /.footer -->
    <div class="tiny-footer">
        <!-- tiny footer -->
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-6">
                    <p>© Copyright 2016 | البراق للترجمة </p>
                </div>
                <div class="col-md-6 col-sm-6 text-right col-xs-6">
                    <p></p>
                </div>
            </div>
        </div>
    </div>
    <!-- /.tiny footer -->
    <!-- back to top icon -->
    <a href="#0" class="cd-top" title="Go to top">Top</a>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="{!!asset('js/jquery.min.js')!!}"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="{!!asset('js/bootstrap.min.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/menumaker.js')!!}"></script>
    <!-- animsition -->
    <script type="text/javascript" src="{!!asset('js/animsition.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/animsition-script.js')!!}"></script>
    <!-- sticky header -->
    <script type="text/javascript" src="{!!asset('js/jquery.sticky.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/sticky-header.js')!!}"></script>
    <!-- slider script -->
    <script type="text/javascript" src="{!!asset('js/owl.carousel.min.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/slider-carousel.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/service-carousel.js')!!}"></script>
    <!-- Back to top script -->
    <script src="{!!asset('js/back-to-top.js')!!}" type="text/javascript"></script>



    
</body>


<!-- Mirrored from jituchauhan.com/borrow/borrow/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 20 Dec 2016 09:03:30 GMT -->
</html>
