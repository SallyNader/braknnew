

<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from jituchauhan.com/borrow/borrow/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 20 Dec 2016 09:01:30 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="we provide all foreign language translation service , we have online language translation services , we are certified language translation services">
    <meta name="keywords" content="Financial Website Template, Bootstrap Template, Loan Product, Personal Loan">
    <title>online language translation services | language translation service providers | foreign language translation service</title>
    <!-- Bootstrap -->
    <link href="{!!asset('css/bootstrap.min.css')!!}" rel="stylesheet">
    <link href="{!!asset('css/style.css')!!}" rel="stylesheet">
    <link href="{!!asset('css/font-awesome.min.css')!!}" rel="stylesheet">
    <link href="{!!asset('css/fontello.css')!!}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{!!asset('css/animsition.min.css')!!}">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700|Merriweather:300,300i,400,400i,700,700i" rel="stylesheet">
    <!-- owl Carousel Css -->
    <link href="{!!asset('css/owl.carousel.css')!!}" rel="stylesheet">
    <link href="{!!asset('css/owl.theme.css')!!}" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body class="animsition">
    <div class="collapse searchbar" id="searchbar">
        <div class="search-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search for...">
                            <span class="input-group-btn">
            <button class="btn btn-default" type="button">Go!</button>
            </span> </div>
                        <!-- /input-group -->
                    </div>
                    <!-- /.col-lg-6 -->
                </div>
            </div>
        </div>
    </div>
    <div class="top-bar">
        <!-- top-bar -->
        <div class="container">
            <div class="row" >
                <div class="col-md-4 hidden-xs hidden-sm">
                    <p class="mail-text">Welcome To our Certified Translation Agency</p>
                </div>
                <div class="col-md-8 col-sm-12 text-right col-xs-12">
                    <div class="top-nav"> <span class="top-text hidden-xs"><a href="{{url('about/contact-us')}}">View Locations</a> </span> <span class="top-text"><a href="">+202 22685650</a></span> <span class="top-text"><a href="">+2 010 69977924</a></span> </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.top-bar -->
    <div class="header">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-sm-12 col-xs-6" style="padding-left: 10px">
                    <!-- logo -->
                    <div class="logo"  >
                        <a href="{{url('/arabic')}}"><img   src="{!!asset('images/logo2.png')!!}" alt="Borrow - Loan Company Website Template" style="background-color: black" ></a>
                    </div>
                </div>
                <!-- logo -->
                <div class="col-md-9 col-sm-12 col-xs-12" style="width:1200px;margin-top:1px;hight:60px;margin-right: 2px">
                    <div id="navigation" >
                        <!-- navigation start-->
                        <ul >
                            <li class="active"><a href="{{url('/')}}" class="animsition-link">Home</a>
                               <!-- <ul>
                                    <li><a href="index.html" title="Home page 1" class="animsition-link">Home page 1</a></li>
                                    <li><a href="index-1.html" title="Home page 2" class="animsition-link">Home page 2</a></li>
                                    <li><a href="index-2.html" title="Home page 3" class="animsition-link">Home page 3</a></li>
                                </ul>-->
                            </li>
                            <li><a href="" class="animsition-link">About</a>
                                <ul>
                                    <li><a href="{{url('about/who-is-Alboraq')}}" title="Loan Image Listing" class="animsition-link">Who Is Alboraq</a></li>
                                    <li><a href="{{url('about/our-advantages')}}" title="Loan Icon Listing" class="animsition-link">Our Advantages</a></li>
                                    <li><a href="{{url('about/our-team')}}" title="Car Loan" class="animsition-link">Our Team</a></li>
                                   
                                    <li><a href="{{url('about/contact-us')}}" title="Home Loan" class="animsition-link">Contact Us</a></li>
                                    <li><a href="{{url('about/sit-emap')}}" title="Education Loan" class="animsition-link">Site Map</a></li>
                                </ul>
                            </li>
                            <li><a href="" class="animsition-link">Our Services</a>
                                <ul>
                                    <li><a href="{{url('translation-service/document-proofreading-editing')}}" title="About us" class="animsition-link">Document Proofreading/Editing</a></li>
                                    <li><a href="{{url('translation-service/document-translation')}}" title="Team" class="animsition-link">Document Translation</a></li>

<li><a href="{{url('translation-service/website-translation')}}" title="Team" class="animsition-link">Website Translation</a></li>
                      
                                    <li><a href="{{url('translation-service/simultaneous-interpretation')}}" title="Team" class="animsition-link">Simultaneous Translation</a></li>
                                    <li><a href="{{url('translation-service/document-transcription')}}" title="Team" class="animsition-link">Transcription</a></li>
                                    <li><a href="{{url('translation-service/video-audio-interpretation')}}" title="Team" class="animsition-link">Audio/Video Interpreting</a></li>
                                    <li><a href="{{url('translation-service/localization')}}" title="Team" class="animsition-link">Localization</a></li>
                                    <li><a href="{{url('translation-service/content-development')}}" title="Team" class="animsition-link">Content Development</a></li>
                                </ul>
                            </li>
                            <li><a href="{{url('document-type-we-translate')}}" class="animsition-link">Document We Translate </a>
                               <!-- <ul>
                                    <li><a href="blog-listing.html" title="Blog Listing" class="animsition-link">Blog Listing</a></li>
                                    <li><a href="blog-single.html" title="Blog Single" class="animsition-link">Blog Single</a></li>
                                    <li><a href="blog-two-column.html" title="Blog Two Column" class="animsition-link">Blog Two Column</a></li>
                                    <li><a href="blog-three-column.html" title="Blog Three Column" class="animsition-link">Blog Three Column</a></li>
                                </ul>-->
                            </li>
                            <li><a href="{{url('languages')}}" class="animsition-link">Languages</a>
                               <!-- <ul>
                                    <li><a href="compare-loan.html" title="Compare Loan" class="animsition-link">Compare Loan</a></li>
                                    <li><a href="loan-calculator.html" title="Loan Calculator" class="animsition-link">Loan Calculator</a></li>
                                    <li><a href="landing-page-car-loan.html" title="Loan Calculator" class="animsition-link">Car Loan 
                                     <small class="highlight">Landing Page</small>

                                     </a></li>
                                    <li><a href="landing-page-home-loan.html" title="Loan Calculator" class="animsition-link">Home Loan 
                                     <small class="highlight">Landing Page</small>

                                     </a></li>
                                    <li><a href="loan-calculator.html" title="Loan Calculator" class="animsition-link">Loan Calculator</a></li>
                                    <li><a href="faq.html" title="Faq" class="animsition-link">Faq page</a></li>
                                    <li><a href="testimonial.html" title="Testimonial" class="animsition-link">Testimonial</a></li>
                                    <li><a href="error.html" title="404 Error" class="animsition-link">404 Error</a></li>
                                    <li><a href="gallery-filter-2.html" class="animsition-link">Gallery</a>
                                        <ul>
                                            <li><a href="gallery-filter-2.html" title="Filterable Gallery 2 column" class="animsition-link">Filterable Gallery 2 column</a></li>
                                            <li><a href="gallery-filter-3.html" title="Filterable Gallery 3 column" class="animsition-link">Filterable Gallery 3 column</a></li>
                                            <li><a href="gallery-masonry.html" title="Masonry Gallery" class="animsition-link">Masonry Gallery</a></li>
                                            <li><a href="gallery-zoom.html" title="Zoom Gallery" class="animsition-link">Zoom Gallery</a></li>
                                        </ul>-->
                                    </li>
                                    <li><a href="{{url('online-translation')}}" class="animsition-link">Online Translation</a>
                                        <!--<ul>
                                            <li><a href="shortcodes-tables.html" title="Table" class="animsition-link">Table</a></li>
                                            <li><a href="shortcodes-tabs.html" title="Tab" class="animsition-link">Tab</a></li>
                                            <li><a href="shortcodes-accordion.html" title="Accordion" class="animsition-link">Accordion</a></li>
                                            <li><a href="shortcodes-alert.html" title="Alert" class="animsition-link">Alert</a></li>
                                            <li><a href="shortcodes-button.html" title="Button" class="animsition-link">Button</a></li>
                                            <li><a href="shortcodes-column.html" title="Column" class="animsition-link">Column</a></li>
                                        </ul>-->
                                   
                            </li>
                            <li><a href="{{url('certifications')}}" title="Contact us" class="animsition-link">Certifications</a></li>
                         <li>   <a href="{{url('translator-jobs')}}" title="Personal Loan" class="animsition-link">Translator Jobs</a></li>


                             <li><a href="{{url('our-customers')}}" title="Contact us" class="animsition-link">Our Customers</a></li>
                             





                        </ul>
                    </div>
                    <!-- /.navigation start-->
                </div>
                <!--
                <div class="col-md-1 hidden-sm">
          
                    <div class="search-nav"> <a class="search-btn" role="button" data-toggle="collapse" href="#searchbar" aria-expanded="false"><i class="fa fa-search"></i></a> </div>
                </div>-->
                <!-- /.search start-->
            </div>
        </div>
    </div>
   <div class="hero">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="hero-captions">
                        <h2 class="hero-title">اللغات التي ندعمها</h2>
                        <p class="hero-text"> </p>
                       <!-- <div class="price-rate">
                            <div class="new-price"><span class="price-big">8.70% </span><small>for new car</small></div>
                            <div class="old-price"><span class="price-big">9.70%</span><small>for new car</small></div>
                        </div>-->
                        <a href="#" class="btn btn-default btn-sm">أرسل الملفات المراد ترجمته</a>
                    </div>
                </div>
               <!-- <div class="col-md-5 col-md-offset-1 col-xs-12">
                    <div class="request-form">
                        <h2>Request Quote Now</h2>
                        <p>Easy to apply for a loan with us,Once you have complete this form. </p>
                        <form method="post" action="http://jituchauhan.com/borrow/borrow/get-quote.php">
                            
                            <div class="form-group">
                                <label class="control-label sr-only" for="name">Name</label>
                                <input id="name" name="name" type="text" placeholder="Name" class="form-control input-md" required="">
                            </div>
                            
                            <div class="form-group">
                                <label class="control-label sr-only" for="email">E-Mail</label>
                                <input id="email" name="email" type="text" placeholder="E-mail" class="form-control input-md" required="">
                            </div>
                            
                            <div class="form-group">
                                <label class="control-label sr-only" for="phone">Phone</label>
                                <input id="phone" name="phone" type="text" placeholder="Phone" class="form-control input-md" required="">
                            </div>
                            
                            <div class="form-group">
                                <label class="control-label sr-only" for="city">City</label>
                                <select id="city" name="city" class="form-control">
                                    <option value="City#1">City#1</option>
                                    <option value="City#2">City#2</option>
                                    <option value="City#3">City#3</option>
                                    <option value="City#4">City#4</option>
                                    <option value="City#5">City#5</option>
                                </select>
                            </div>
                            <div class="slide-ranger">
                                <p id="slider-range-min"></p>
                                <label for="amount" class="control-label sr-only">Loan Amount</label>
                                <input type="text" id="amount" readonly class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" class="btn btn-default btn-block">Send A Request</button>
                            </div>
                        </form>
                    </div>
                </div>-->
            </div>
        </div>
    </div>
 <div class="wm-footer-newslatter">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                           
                        </div>
                    </div>
                </div>
            </div> <div class="wm-footer-newslatter">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                           
                        </div>
                    </div>
                </div>
            </div>
           
            <p></p>

            
<div class="container-fluid" style="margin-left: 20px;margin-right: 30px;margin-bottom: 50px;text-align:left">
  <div class="row" style="">
    <!-- Nav left -->
    <ul class="nav col-md-2" id="leftTabs" style="margin-top: 80px">
      <li class="active">
        <a href="#a_tab" data-toggle="tab">
          <span></span><strong style="color: #f51f8a;font-size: 130%">الرائجة</strong>        </a>
      </li>
      <li>
        <a href="#b_tab" data-toggle="tab">
          <span></span><strong style="color: #f51f8a;font-size: 130%">أ</strong>
        </a>
      </li>
    <!--  <li>
        <a href="#c_tab" data-toggle="tab">
          <span></span>ItemC - TABS!
        </a>
      </li>-->
      <li>
        <a href="#d_tab" data-toggle="tab">
          <span></span>  <strong style="color: color: #f51f8a;font-size: 130%"> ب</strong>
        </a>
      </li>

      <li>
        <a href="#e_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ت</strong>
        </a>
      </li>



      <li>
        <a href="#f_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ث</strong>
        </a>
      </li>


      <li>
        <a href="#g_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ج</strong>
        </a>
      </li>


      <li>
        <a href="#h_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ح</strong>
        </a>
      </li>
      <li>
        <a href="#i_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">خ</strong>
        </a>
      </li>
      <li>
        <a href="#j_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">د</strong>
        </a>
      </li>
      <li>
        <a href="#k_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ذ</strong>
        </a>
      </li>
      <li>
        <a href="#l_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ر</strong>
        </a>
      </li>
      <li>
        <a href="#m_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ز</strong>
        </a>
      </li>




      <li>
        <a href="#n_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">س</strong>
        </a>
      </li>



      <li>
        <a href="#o_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ش</strong>
        </a>
      </li>





      <li>
        <a href="#p_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ص</strong>
        </a>
      </li>



      <li>
        <a href="#q_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ض</strong>
        </a>
      </li>



      <li>
        <a href="#r_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ط</strong>
        </a>
      </li>


      <li>
        <a href="#s_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ظ</strong>
        </a>
      </li>




      <li>
        <a href="#t_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ع</strong>
        </a>
      </li>





      <li>
        <a href="#u_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">غ</strong>
        </a>
      </li>




      <li>
        <a href="#v_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ف</strong>
        </a>
      </li>




      <li>
        <a href="#w_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ق</strong>
        </a>
      </li>





      <li>
        <a href="#x_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ك</strong>
        </a>
      </li>








      <li>
        <a href="#y_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ل</strong>
        </a>
      </li>




      <li>
        <a href="#z_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">م</strong>
        </a>
      </li>







      <li>
        <a href="#aa_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ن</strong>
        </a>
      </li>

 <li>
        <a href="#bb_tab" data-toggle="tab">
          <span></span> <strong style="color: #f51f8a;font-size: 130%">ه</strong>
        </a>
      </li>



     

    </ul>
    <!-- Nav content -->
    <div class="tab-content col-md-10" style="text-align: left;margin-top: 80px">
      <div class="tab-pane active" id="a_tab">
              <h1 style="margin-bottom: 59px"></h1>
        <h3 style="color: #f51f8a">الترجمة إلى الإنجليزية

</h3>
        <p>English is the third largest language by number of native speakers, after Mandarin and Spanish,Estimates that include second language speakers vary greatly, from 470 million to more than 1 billion.</p>

  <h3 style="color: #f51f8a">Arabic Translation</h3>
        <p>As the 6th most spoken language in the world, professional Arabic translation is extremely high in demand.  It also happens to be one of the languages we specialize in.  We offer Arabic translation services in all industries, areas of specialized language services, and all regional dialects.
</p>

 <h3 style="color: #f51f8a">Portuguese translation</h3>
        <p>Portuguese is a widely spoken language with around 210 million native speakers. It also serves as the official language of nine countries. Approximately half the population of South America speaks Portuguese. Furthermore, Brazil is a Portuguese-speaking country.
</p>


<h3 style="color: #f51f8a">Russian Translation</h3>
        <p>Russian is widely used across Eurasia. It has the largest number of native speakers in Europe, and is the most widely spoken among Slavic languages. At present it is also widely used outside Russia. More than a fourth of the global scientific literature is published in Russian. Russian is also one of the six official languages of the United Nations.
</p>

        <h3 style="color: #f51f8a">French translation</h3>
        <p>French is the native language of over a 100 million people. A further 60 million use it as second language. French is also used as an official language in a lot of international and multinational companies, and organizations like UNO, UNESCO and Red Cross. Overall, it is commonly used across 51 countries and 5 continents.
</p>
        <h3 style="color: #f51f8a">German translation</h3>
        <p>The German language is one of the most widely spoken mother languages in the European Union. Around the world, there are presently about 105 million native German speakers, and another 80 million non-native ones. German comes right after English and French among the most popularly taught languages of the world.
</p>
        <h3 style="color: #f51f8a">Japanese translation</h3>
        <p>More than 130 million people across the world use the Japanese language. Combine this with the fact that Japan is associated with rapid technological development which has turned it into an international business haven. This has created a great demand for Japanese language translation experts.
</p>


         <h3 style="color: #f51f8a">Chinese Translation</h3>
        <p>More than one billion people, or nearly 20 percent of the world's population uses Chinese as their native language. Standard Mandarin has been designated as the official language of People’s Republic of China. It is also one of the official languages of the United Nations.
</p>

         

        

        <h3 style="color: #f51f8a">Italian Translation</h3>
        <p>Italian is the native language of around 60 to 70 million people around the world. Another 40 to 50 million people use it as a cultural or second language. It is the official language of Italy, and also serves as one of the official languages of Switzerland.  All these facts serve to increase the worldwide importance of the Italian language.
</p>

        <h3 style="color: #f51f8a">Polish Translation</h3>
        <p>Polish is spoken by around 38 million people in Poland, most of whom are mother tongue speakers. The global population of native Polish speakers is somewhere between 40 to 48 million. This makes Polish the most popular Slavic language after Russian.
</p>


        <h3 style="color: #f51f8a">Thai Translation</h3>
        <p>Thailand provides great business opportunities being a much desired tourist destination. With the Thai language spoken in various dialects by about 65 million people in the country, the requirement for Thai translation services is growing increasingly. But Thai is a difficult language to master, especially for the westerners, so getting professional Thai translators can be a challenging task.
</p>
      </div>
      <div class="tab-pane" id="b_tab">
        <h1></h1>


        <h3 style="color: #f51f8a">Arabic Translation</h3>
        <p>As the 6th most spoken language in the world, professional Arabic translation is extremely high in demand.&nbsp; It also happens to be one of the languages we specialize in.&nbsp; We offer Arabic translation services in all industries, areas of specialized language services, and all regional&nbsp;dialects.
</p>


<h3 style="color: #f51f8a">Abkhazian Translation</h3>
        <p>Abkhazian is also referred to as Abkhaz, it is spoken in the country of Abkhazia by around 100,000 people. Outside Abkhazia it is spoken by thousands of people living in Turkey, Jordan, Adjara, Syria, Russia and some other western countries.
</p>


<h3 style="color: #f51f8a">Afrikaans Translation</h3>
        <p> Majority of Afrikaans speakers can be found in South Africa and Namibia. Afrikaans is a part of the Indo-European languages. It was derived from Dutch hence it is further classified as Low Franconian West Germanic. Afrikaans is mutually intelligible with Dutch.
</p>

<h3 style="color: #f51f8a">Albanian Translation</h3>
        <p> Albanian translation services are rising in demand due to its ideal location for international business and investment.&nbsp; As a &quot;gateway to Southern Europe,&quot;&nbsp;and both Italy and Greece being quite accessible from Albania, Albanian translation services are some of our most requested language services.
</p>


<h3 style="color: #f51f8a">Amharic Translation</h3>
        <p>Amharic is primarily spoken in North Central Ethiopia. Native speakers of the language are known as Amharas. Amharic is the second most popularly spoken Semitic language around the world after Arabic.
</p>


<h3 style="color: #f51f8a">Armenian Translation</h3>
        <p>Armenian is the official language of the Republic of Armenia. Apart from the residents of Armenia it is widely spoken by Armenian people living in various parts of the world. The language is spoken in two major dialects, these are, Eastern Armenian and Western Armenian.
</p>


<h3 style="color: #f51f8a">Assamese Translation</h3>
        <p>Assamese language belongs to the Indo-Aryan family of languages and is spoken primarily in the Indian state of Assam. Outside Assam it is also spoken by relatively smaller groups of speakers in other north-eastern Indian states like Arunachal Pradesh.&nbsp;
</p>


<h3 style="color: #f51f8a">Aymara Translation</h3>
        <p>Aymara is spoken in the Andes region. It has about 2.2 million speakers, most of whom live in Peru, Bolivia, Chile and Argentina. Aymara is spoken in three major dialects, they are Northern, Southern and Intermediate Aymara.
</p>


<h3 style="color: #f51f8a">Azerbaijani Translation</h3>
        <p>Azerbaijani is spoken by near about 31 million people spread across Azerbaijani, Turkey, Armenia, Iran, Iraq, Russia, Georgia and Syria. It is spoken in two primary forms North Azerbaijani and South Azerbaijani.
</p>
      </div>
      <div class="tab-pane" id="d_tab">
        <h1></h1>


        <h3 style="color: #f51f8a">Bulgarian Translation</h3>
        <p>Bulgarian Language is spoken by around 9 to 12 million speakers around the world. It has also been designated as one of the official languages for the European Union.
</p>


<h3 style="color: #f51f8a">Bahasa Translation</h3>
        <p> Bahasa or Indonesian is the national and official language of Indonesia. It is spoken by about 240 million people including the whole population of Indonesia. The language is popularly called Bahasa Indonesia which means the &ldquo;Language of Indonesia&rdquo;. It has been developed from Malay, which makes both languages mutually intelligible.
</p>


<h3 style="color: #f51f8a">Bashkir Translation</h3>
        <p>Bashkir language belongs to the family of Turkic languages. Majority of its speakers can be found in the Republic of Bashkortostan. There are over a million speakers of the Bashkir language in Russia, a majority of whom are native speakers. Other countries with substantial population of Bashkir speakers are Uzbekistan and Kazakhstan.&nbsp;
</p>


<h3 style="color: #f51f8a">Basque Translation</h3>
        <p>Basque is the native language of the Basque people living in Basque Country. The language has about 1 million speakers out of which approximately 630,000 are mother tongue speakers. The standardized version of Basque is called Batua, apart from that Basque is spoken in six major dialects.&nbsp;
</p>


<h3 style="color: #f51f8a">Belarusian Translation</h3>
        <p>Belarusian language comes under the Eastern Slavonic language group. It is spoken by around 7.5 million speakers most of whom can be found in Belarus. Belarusian and Russian are closely related, hence both languages share a high degree of mutual intelligibility.&nbsp;
</p>


<h3 style="color: #f51f8a">Bengali Translation</h3>
        <p> Bengali speakers are mainly found in the Indian states of West Bengal, Assam and Tripura. Around the world Bengali has almost 230 million speakers making it the fifth or sixth most popularly spoken language in the world. Bengali also serves as the primary language of Bangladesh.
</p>


<h3 style="color: #f51f8a">Berber Translation</h3>
        <p>Berber is actually a closely related group of languages spoken by Berber communities in Mali and Niger and in Algeria, Libya, Egypt, Tunisia, and Morocco. It is also spoken by smaller groups living in the northern regions of Sahel and in Sahara.
</p>


<h3 style="color: #f51f8a">Bhutani Language</h3> <p>The national language of Bhutan is known as Dzongkha. It is spoken in as many as 13 dialects across the country. Dzongkha is written using the Tibetan alphabet, however the style of writing is significantly different.&nbsp;</p>

<h3 style="color: #f51f8a">Bosnian Translation</h3><p> The bulk of Bosnian speakers can be found residing in Bosnia and Herzegovina. Then there is another Bosnian dominated region Herzegovina. Bosnian language is close to and mutually intelligible with both Serbian and Croatian.</p>

<h3 style="color: #f51f8a">Burmese Translation</h3><p> The Burmese language is the native language of Bamar who make for the majority ethnic group in Burma. Burmese or Myanmar, as referred to by the government is spoken by over 32 million people in the country not including the ethnic minorities who use it as a second language.&nbsp;</p>

      </div>




      <div class="tab-pane" id="e_tab">
        <h1></h1>

<h3 style="color: #f51f8a">Chinese Translation</h3><p> More than one billion people, or nearly 20 percent of the world&#39;s population uses Chinese as their native language. Standard Mandarin has been designated as the official language of People&rsquo;s Republic of China. It is also one of the official languages of the United Nations.</p>

<h3 style="color: #f51f8a">Catalan Translation</h3><p> Catalan is spoken by roughly 12 million speakers across the world. It is used as the official language in Catalonia, Alghero, Valencia, and the Balearic Islands. Catalan originally developed from Vulgar Latin and though it has developed into a distinct language, its vocabulary still shows considerable influence of Vulgar Latin.</p>

<h3 style="color: #f51f8a">Cherokee Translation</h3><p> The Cherokee language is referred to as Tsalagi by native speakers of the language. It is the primary language spoken in the Cherokee Nation in Oklahoma by about 10,000 people who live in the region. The Cherokee language uses a syllabary system for writing.</p>

<h3 style="color: #f51f8a">Chewa Translation</h3><p> Chewa belongs to the family of Bantu languages. It is also known as Chichewa which means &ldquo;language of the Chewa tribe&rdquo;. The language is spoken in various parts of South-Central Africa and total number of speakers is more than 6 million.&nbsp;</p>

<h3 style="color: #f51f8a">Corsican Translation</h3><p> Corsican language is also natively known as Corsu or Lingua Corsu. It is mainly spoken in Corsican and Sardinian islands in France and Italy respectively. The language is related to Italian and shares many similarities with the Tuscany dialect of Italian.&nbsp;</p>

<h3 style="color: #f51f8a">Chuukese Translation</h3><p> Chuukese Language is also alternatively known as Trukese. It comes from the Austronesian group of languages and is a Trukic language with around 45,000 speakers. Chuukese speakers are mainly found in Chuuk in Caroline Islands.&nbsp;</p>

<h3 style="color: #f51f8a">Croatian Translation</h3><p> Croatia and its people&nbsp;have worked to establish themselves and their language as independent&nbsp;and unique from&nbsp;other&nbsp;neighboring countries - namely Bosnia, Serbia and Montenegro -&nbsp;despite their mutual intelligibility and extreme similarity.&nbsp; It is never, ever wise&nbsp;to use the same&nbsp;interpretation or&nbsp;document translation for a Croatian audience as you would for a Bosnian or Serbian one - that would be a&nbsp;cultural faux pas.&nbsp; However, only the most qualified, experienced&nbsp;professional translators will understand how to translate documents so that they cater&nbsp;linguistically to their respective Croatian, Bosnian&nbsp;and Serbian recipients or audience.</p>

<h3 style="color: #f51f8a">Czech Translation</h3><p> Czech has about 12 million native speakers, a majority of whom live in the Czech Republic. Apart from that you can also find users of the Czech language in Ukraine, United States, Austria, Canada, Poland and Israel.</p>




      </div>



      <div class="tab-pane" id="f_tab">
        <h1></h1>

       <h3 style="color: #f51f8a">Danish Translation</h3><p> The Danish language has about 6 million users a majority of which live in Denmark. Apart from Denmark it is recognized as an official language in Danish territories of Faroe Islands and Greenland. It also serves as one of the official languages for the European Union. Danish speakers can also be found in the U.S., Canada and Argentina.</p>

<h3 style="color: #f51f8a">Divehi Translation</h3><p> Divehi is also referred to as Dhivehi and Mahl. It belongs to the Indo-Aryan languages group and is spoken by approximately 350,000 people most of whom live in the Maldives. It is believed by many linguists that Divehi is a descendant of the Old Sinhala language.&nbsp;</p>

<h3 style="color: #f51f8a">Dutch translation</h3><p> The Dutch language originated from West Germany. It is the mother language of more than 22 million people. Another 5 million use it as their second language. Native Dutch speakers are mostly found in the Netherlands, Suriname and Belgium. Other comparatively small groups of Dutch speakers can be found in Germany, France and several former Dutch colonies.</p>

      </div>


      <div class="tab-pane" id="g_tab">
        <h1></h1>


<h3 style="color: #f51f8a">Estonian Translation</h3><p>Estonian is the official language of Estonia. It is used by approximately 1.1 million people living in Estonia. Apart from that Estonian is also used by thousands of people belonging to various &eacute;migr&eacute; communities. The language is closely related to Finnish.</p>

<h3 style="color: #f51f8a">Elfdalian Translation</h3><p> Elfdalian language is mainly spoken in Northern Dalarna in Sweden. It has been traditionally viewed as a dialect of the Swedish language, but there language experts who hold it as an independent language on its own.</p>

<h3 style="color: #f51f8a">Esperanto Translation</h3><p> Esperanto is a constructed international auxiliary language. In fact it is the most widely used among such languages. Esperanto was created in 1887 by L. L. Zamenhof, who intended it as a universal language which could promote peace and understanding internationally.&nbsp;</p>

      </div>


      <div class="tab-pane" id="h_tab">
        <h1></h1>

        <h3 style="color: #f51f8a">French translation</h3><p> French is the native language of over a 100 million people. A further 60 million use it as second language. French is also used as an official language in a lot of international and multinational companies, and organizations like UNO, UNESCO and Red Cross. Overall, it is commonly used across 51 countries and 5 continents.</p>

<h3 style="color: #f51f8a">Faroese Translation</h3><p> The Faroese language is a West Nordic language, it comes under the North Germanic family of languages. The language is spoken by about 47,000 people, a majority of whom are based in Faroe Islands.</p>

<h3 style="color: #f51f8a">Fijian Translation</h3><p> Fijian belongs to the Malayo-Polynesian family of languages. It is primarily spoken in Fiji where there are 450,000 first language Fijian speakers. Additionally there are about 200,000 second language Fijian speakers. Fijian serves as the co-official language of Fiji.</p>

<h3 style="color: #f51f8a">Filipino Translation </h3><p>&nbsp;Filipino translation is one of our most&nbsp;frequently requested services.&nbsp;&nbsp;With over 64 million Filipino language speakers -&nbsp;also&nbsp;called Tagalog in the Phillipines -&nbsp;professional Filipino translation is needed across scores of industries and businesses.&nbsp; English to Filipino translation service provides communication between American companies and their partners in the Phillipines.</p>

<h3 style="color: #f51f8a">Finnish Translation</h3><p> Finnish is the main language of Finland. It is spoken by over 6 million native speakers who make up about 92% of the Finnish population. One can also find Finnish speakers in various parts of the world spoken mostly by ethnic Finns. Finnish serves as one of the official languages of the European Union and has also been named one of the minority languages of Sweden.</p>

<h3 style="color: #f51f8a">Flemish Translation</h3><p> Flemish actually refers to Dutch as it is spoken in Belgium. Around 60% of the Dutch population speaks Flemish. There are two main Flemish dialects, East and Flemish.&nbsp;</p>

<h3 style="color: #f51f8a">Frisian Translation</h3><p>Frisian is actually of group of Germanic languages. There are roughly 500,000 speakers of Frisian language and they are mostly found living in the Netherlands, Germany and Denmark.</p>

<h3 style="color: #f51f8a">Fula Translation</h3><p> Fula belongs to the Niger-Congo languages group. It is mostly used in West Africa by the Fulani or Fula tribe. The language is also known by other names like Pular or Pulaar (the western dialects) and Fulfulde (the eastern and central dialects).</p>

      </div>


      <div class="tab-pane" id="i_tab">
        <h1></h1>
       <h3 style="color: #f51f8a">German translation</h3><p> The German language is one of the most widely spoken mother languages in the European Union. Around the world, there are presently about 105 million native German speakers, and another 80 million non-native ones. German comes right after English and French among the most popularly taught languages of the world.</p>

<h3 style="color: #f51f8a">Galician Translation</h3><p>Galician is the native language of the country of Galicia. There it is spoken by approximately 3 million people. Additionally the language is also spoken in autonomous neighboring communities, as well as in Northern Portugal.</p>

<h3 style="color: #f51f8a">Georgian Translation</h3><p> Georgian serves as the official language of Georgia. It has around 3.9 million native speakers in Georgia itself. Beyond the country it is spoken in Russia, Turkey, Iran, Europe and USA.</p>

<h3 style="color: #f51f8a">Greek Translation</h3><p> Greek was one of the languages that were originally used in the Gospels. In the present age, it is serves as the native language of approximately 15-25 million people who can be found in Greece, Cyprus, Albania,&nbsp; former Yugoslav Republic of Macedonia, Armenia, Bulgaria, Italy, Turkey, Romania, Georgia, Ukraine,&nbsp; Moldova, Russia, Jordan, Egypt. It is also used by emigrants living in the United States, Germany, Australia, and other parts of the world.</p>

<h3 style="color: #f51f8a">Greenlandic Translation</h3><p>Greenlandic is a part of the Eskimo-Aleut languages family. There are 50,000 Greenlandic speakers in Greenland and 7,000 in Denmark this makes it the most frequently spoken Eskimo-Aleut language. &nbsp;</p>

<h3 style="color: #f51f8a">Gujarati Translation</h3><p> The Gujarati language has around 46 million speakers most of whom reside in Gujarat, Indian state. Native Gujarati speakers can also be found in other Indian states like Madhya Pradesh, Maharashtra, Rajasthan, and Karnataka. They are widely spread out outside India and can be found in Pakistan, Bangladesh, United Kingdom, USA, Fiji, South Africa, Kenya, Tanzania, Uganda, Mauritius, Oman, Singapore, Zambia and Zimbabwe.&nbsp;</p>

<h3 style="color: #f51f8a">Guarani Translation</h3><p> Guaran&iacute; is a native language of South America. It is classified under the Tup&iacute;-Guaran&iacute; subgroup of Tupian languages. Guarani has roughly 4.6 million speakers a major percentage of whom live in Paraguay. Guarani is an official language of Paraguay along with Spanish.</p>

      </div>


      <div class="tab-pane" id="j_tab">
        <h1></h1>

        <h3 style="color: #f51f8a">Hebrew Translation</h3><p> There are seven million speakers of Modern Hebrew. Most of them live in Israel. Hebrew also serves as an official language of Israel. It is a historically important language as many of the Jewish and Christian Holy Scriptures were originally written in Hebrew.&nbsp;</p>

<h3 style="color: #f51f8a">Haitian-Creole Translation</h3><p> The Haitian Creole language is also known simply as Creole or Krey&ograve;l. It is spoken by almost the entire population of Haiti which is 9 million. There are an additional 400,000 speakers of Creole who have immigrated to various countries around the world.</p>

<h3 style="color: #f51f8a">Hausa Translation</h3><p>Hausa Language belongs to the Afro-Asiatic family of languages. There are nearly 39 million Hausa speakers out of which 24 million are native speakers and the rest second language speakers. Northern Nigeria regards Hausa as the official language while Niger holds it as the national language.</p>

<h3 style="color: #f51f8a">Hawaiian Translation</h3><p>Hawaiian is a Polynesian language which developed in the island of Hawaii, on which it has been named. It is the co-official language for the State of Hawaii and has about 8,000 speakers.</p>

<h3 style="color: #f51f8a">Hindi Translation</h3><p> Hindi belongs to the Indo-Aryan languages group. It is identified as the mother language of a major portion of the population of North and Central India. Hindi speakers also form a substantial population of Indians living in the USA. The language is ranked among the most frequently spoken ones in the world.</p>

<h3 style="color: #f51f8a">Hmong Translation</h3><p> Hmong refers collectively to a group of dialects that belong to the West Hmongic branch under the Hmong-Mein languages family. There are nearly 4 million speakers of Hmong out of which 200,000 are Hmong Americans.&nbsp;</p>

<h3 style="color: #f51f8a">Hungarian Translation</h3><p> Hungarian which is a Uralic language is quite different from most other European languages. It is chiefly spoken by the residents of Hungary and the total number of native Hungarian speakers in the world is over 14.5 million.</p>
      </div>



      <div class="tab-pane" id="k_tab">
        <h1></h1>

        <h3 style="color: #f51f8a">Italian translation</h3><p> Italian is the native language of around 60 to 70 million people around the world. Another 40 to 50 million people use it as a cultural or second language. It is the official language of Italy, and also serves as one of the official languages of Switzerland.&nbsp; All these facts serve to increase the worldwide importance of the Italian language.</p>

<h3 style="color: #f51f8a">Ibibio Translation</h3><p>Ibibio belongs to the Benue-Congo language group. It has approximately 1.5 to 2 million speakers living mainly in the Nigerian Cross River States and the Akwa Ibom State. Ibibio is also known as Ibibio-Efik language.</p>

<h3 style="color: #f51f8a">Icelandic translation</h3><p>Icelandic is a Germanic language bearing some relation to Norwegian, Danish and Swedish. There are around 320,000 native speakers based in Iceland, and pockets of Icelandic speakers can also be found in the US, Canada and Denmark.</p>

<h3 style="color: #f51f8a">Indonesian Translation </h3><p>Indonesian is used across Indonesia as a common language in which the citizens can communicate. While there are hundreds of indigenous languages in Indonesia, Indonesian is the country&rsquo;s official language and the one in which people communicate, regardless of which other dialects they may speak. Indonesian is also spoken in East Timor and the Philippines.</p>

<h3 style="color: #f51f8a">Interlingua Translation</h3><p> Interlingua is an international auxiliary language which was created with the intention of having an international language that assimilated vocabulary and grammatical concepts from various major languages from all over the world and was very easy to learn.&nbsp;</p>

<h3 style="color: #f51f8a">Inuktitut Translation</h3><p> Inuktitut is classified under the Eskimo-Aleut languages family and has around 65,000 speakers. Most Inuktitut speakers live in Alaska, Greenland, Canada and Siberia. The language is spoken in a variety of dialects across the Arctic.</p>

<h3 style="color: #f51f8a">Inupiaq Translation</h3><p> Inupiaq is the name given to a group of dialects that are a part of the Inuit language and are popular in north and north-western Alaska. It has over 2,000 speakers, who are called Inupiat. The language is also known by alternative names like Inupiak and Inupiatun.</p>

<h3 style="color: #f51f8a">Irish Translation</h3><p> Irish, which is spoken primarily in Ireland by about 20,000 to 80,000 native Irish speakers, plays an important symbolic role in the country. It is also recognized as one of the official languages of the European Union. At present there are more than 1.6 million Irish speakers all over the world.</p>

      </div>


      <div class="tab-pane" id="l_tab">
        <h1></h1>

        <h3 style="color: #f51f8a">Japanese translation</h3><p> More than 130 million people across the world use the Japanese language. Combine this with the fact that Japan is associated with rapid technological development which has turned it into an international business haven. This has created a great demand for Japanese language translation experts.</p>

<h3 style="color: #f51f8a">Javanese Translation</h3><p> Java is the natively spoken language in the eastern and central region of Java, Indonesia. It has more than 75 million native speakers. It is written using the Javanese script which has been influenced by a number of scripts including the Brahmi script, the Latin script, and an adapted version of the Arabic script.&nbsp;</p>

      </div>

      <div class="tab-pane" id="m_tab">
        <h1></h1>

        <h3 style="color: #f51f8a">Korean Translation</h3><p> Korean is the official language of North and South Korea. It is spoken by around 72 million people in its native region of Korean peninsula. Beyond that it is used as first language by over 2 million people in China and another 2 million use it in the US. Furthermore, there are about 500,000 Korean speakers in Russia in its Kazakhstan and Uzbekistan regions. Even Japan has around 700,000 Korean speakers.</p>

<h3 style="color: #f51f8a">Kannada Translation</h3><p> Kannada is an Indian Dravidian language. The largest numbers of Kannada speakers are found in the Indian state of Karnataka. Kannada is the 27th most widely spoken language in the world with 35 million speakers. Kannadigas is the term used to refer to the native speakers of Kannada.&nbsp;</p>

<h3 style="color: #f51f8a">Kanuri Translation</h3><p>Kanuri refers to the dialect continuum that is used by people in the area of the Lake Chad Basin. Major concentration on Kanuri speakers can be found in Niger, Chad, Nigeria and Cameroon and relatively smaller groups can be found in Sudan and southern Libya.</p>

<h3 style="color: #f51f8a">Kashmiri Translation</h3><p> Kashmiri, locally known as Koshur is belongs to the sub-group Dardic under the Indo-Aryan languages. It has approximately 5.5 million speakers in India and 1 million speakers in Pakistan.&nbsp;</p>

<h3 style="color: #f51f8a">Kazakh Translation</h3><p> Kazakh serves as the official language of Kazakhstan. It is a Turkic language closely related to Karakalpak and Nogai. It is locally referred to as Qazaq tili. The language has over 10 million native speakers who can be found in the area stretching from Tian Shan Mountains to Ural Mountains.</p>

<h3 style="color: #f51f8a">Khmer Language</h3><p>Khmer or Cambodian language serves as the national language of Cambodia, it is spoken by about 15-20 million people.</p>

<h3 style="color: #f51f8a">Kirghiz Translation</h3><p>Kirghiz or Kyrgyz is a Turkic language with nearly 4 million speakers. Most of the native Kyrgyz speakers are found in Kyrgyzstan and China. Kirghiz is recognized as an official language in Kyrgyzstan along with Russian.</p>

<h3 style="color: #f51f8a">Konkani Translation</h3><p> Konkani belongs to the Indo-Aryan languages family. It is spoken by over 7 million speakers most of whom live along the Konkan coats in India. The various Konkan speaking regions include Goa, Maharashtra, North Canara and South Canara.&nbsp;</p>
      </div>






       <div class="tab-pane" id="n_tab">
        <h1></h1>

        <h3 style="color: #f51f8a">Latin translation</h3><p> Latin which originated in an area called Latium around Rome, achieved significance as the official language of the Roman Empire. At present Ecclesiastical Latin is used as the official language of the Vatican City and the Catholic Church which have considerable influence around the world. This alone ensures that Latin would thrive for a long time to come.</p>

<h3 style="color: #f51f8a">Laothian Translation</h3><p> Laothian is also known alternatively as Laotian or Lao. It belongs to the Kradai languages family and is used as the official language in the country of Laos. It is referred to as Isan language in Thailand.&nbsp;</p>

<h3 style="color: #f51f8a">Latvian Translation</h3><p> Latvian which is the official language of Latvia has around 1.4 million native speakers. A further 150,000 can be found living abroad. A peculiarity associated with the Latvian language is that it has a significantly large number of non-native speakers.</p>

<h3 style="color: #f51f8a">Lingala Translation</h3><p> Lingala is a member of the Bantu languages family. It is spoken by approximately 10 million people in the north-west of Congo-Kishasa and across a major area of Congo-Brazzaville. Both the countries use their own dialects, other dialects include Spoken and Standard Lingala.&nbsp;</p>

<h3 style="color: #f51f8a">Lithuanian Translation</h3><p>Lithuanian is the official language of Lithuania. It also serves as one of the official languages of the European Union.&nbsp; There are over 2.96 million native speakers of Lithuanian in the country of Lithuania itself. The languages is also spoken by around 170,000 people living in various other parts of the world.</p>

      </div>







       <div class="tab-pane" id="o_tab">
        <h1></h1>

        <h3 style="color: #f51f8a">Malay Translation</h3><p> Malay is chiefly used by the Malay people and those who may belong to other ethnic groups, but live in Peninsular Malaysia, central eastern Sumatra, Singapore, the Riau Islands, certain areas of the coast of Borneo, and southern Thailand. Malay has around 200 million speakers around the world, making it the tenth most popularly spoken languages.</p>

<h3 style="color: #f51f8a">Maori Translation</h3><p> Maori language is also called by the names &ldquo;te reo Maori&rdquo; and &ldquo;te reo&rdquo;. It is a part of the Eastern Polynesian family of languages. Maori has nearly 100,000 speakers most of whom live in New Zealand and its neighboring islands.&nbsp;</p>

<h3 style="color: #f51f8a">Macedonian Translation</h3><p> Macedonian has over 1,644,815 native speakers and serves as the official language of Macedonia. Apart from Macedonia, one can find native Macedonian speakers living in Bulgaria, Serbia and Albania which are neighboring countries of Macedonia.</p>

<h3 style="color: #f51f8a">Malagasy Translation</h3><p> Though Malagasy is the native language used in Madagascar, it is not related to any African languages spoken in the neighborhood. It belongs to the Austronesian languages family under the sub-group of Malaya-Polynesian languages. It&#39;s used by a population of nearly 17 million.&nbsp;</p>

<h3 style="color: #f51f8a">Marathi Translation</h3><p> Marathi is one of the oldest among Indo-Aryan languages. It is primarily spoken in India in the State of Maharashtra. Apart from being the official language of the State of Maharashtra it is also recognized as one of the official languages of India and a co-official language of Goa. There are about 90 million speakers of Marathi all over the world.&nbsp;</p>

<h3 style="color: #f51f8a">Malayalam Translation</h3><p> Malayalam belongs to the Dravidian languages group and is primarily spoken in the state of Kerala in South India. Outside India Malayalam is spoken by Indians who have settled down in the Persian Gulf, Singapore, Australia, United States and Europe. Malayalam is recognized as one of the official languages of India, as well as the State of Kerala.&nbsp;</p>

<h3 style="color: #f51f8a">Maltese Translation</h3><p> Maltese is the national language of Malta and also serves as one of the official languages of the European Union. The Maltese language originated from an Arabic dialect called Siculo-Arabic in Malta, Southern Italy and Sicily. As a result of this, roughly half of its vocabulary Maltese has been developed from Sicilian and Italian.</p>

<h3 style="color: #f51f8a">Moldavian Translation</h3><p> Moldavian or Moldovan serves as the official language of the Republic of Moldova. It is actually a dialect of Romanian and is referred to by both names due to political reasons. Apart from Moldova it is also used as an official language in Transnistria.&nbsp;</p>

      </div>





       <div class="tab-pane" id="p_tab">
        <h1></h1>

       <h3 style="color: #f51f8a">Norwegian Translation</h3><p> Norwegian belongs to the category of North Germanic languages. It is closely related to and hence quite similar to Danish and Swedish. A unique aspect associated with Norwegian is that the government of Norway recognizes two written forms of Norwegian as official.</p>

<h3 style="color: #f51f8a">Nauru Translation</h3><p> Nauru language is a member of the Austronesian languages group. It is primarily spoken in the Republic of Nauru where it approximately 7,000 speakers. Most Nauru speakers are fluent in English as well.</p>
<h3 style="color: #f51f8a">Nepali Translation</h3><p> The Nepali language which is the major language of Nepal, serves as the official language of the country and is also recognized as one of the official languages of India. There are about eleven million native Nepali speakers living in Nepal. Other can be found in India, Burma and Bhutan taking the figure to seventeen million.&nbsp;</p>

      </div>



       <div class="tab-pane" id="q_tab">
        <h1></h1>

        <h3 style="color: #f51f8a">Oromo Translation</h3><p> Oromo is also referred to as Afan Arsi, Afan Boran, Afaan Oromoo, and Oromiffa. It belongs to the Afro-Asiatic family of languages. Oromo is the mother language of about 25 million people most of whom are a part of the Cushitic family. Oromo speakers are mainly concentrated in the Oromia region in Ethiopia.</p>

<h3 style="color: #f51f8a">Occitan Translation</h3><p> Occitan is classified as a Romance language and is spoken by people living in the southern portion of France and Occitan Valleys in Italy. Occitan language is quite closely related to Catalan, hence it has been declared as one of the official languages of Catalonia, Spain.</p>

<h3 style="color: #f51f8a">Oriya Translation</h3><p> Oriya is a part of the Indo-Aryan languages group which in turn is a part of the Indo-European languages family. It has almost 31 million speakers a majority of whom stay in Orissa. Smaller communities of Oriya speakers are found in other parts of India specially Gujarat, Jharkhand and West Bengal.</p>

      </div>






       <div class="tab-pane" id="r_tab">
        <h1></h1>

        <h3 style="color: #f51f8a">Portuguese translation</h3><p> Portuguese is a widely spoken language with around 210 million native speakers. It also serves as the official language of nine countries. Approximately half the population of South America speaks Portuguese. Furthermore, Brazil is a Portuguese-speaking country.</p>

<h3 style="color: #f51f8a">Papiamentu Translation</h3><p> Papiamentu language is also referred to as Papiamento. It is a Creole language whose development has been influenced by varied languages like Dutch, Portuguese, French, Spanish, English and a number of African languages. It is spoken by around 333,000 people. &nbsp;</p>

<h3 style="color: #f51f8a">Pashto Translation</h3><p> Pashto is spoken by almost 45 million people, a majority of whom can be found living in Afghanistan. Pashto speakers can also be found in other parts of the world like India, Pakistan, United States, UK, UAE, Saudi Arabia, Thailand and Australia.</p>

<h3 style="color: #f51f8a">Persian Translations</h3><p>Though Persian originated in Iran and is primarily spoken by the Persian people, the wide spread global reach of the Persian Empire in the past has ensured that the language spread out to many countries all over the world, including Tajikistan and Afghanistan. Iran, Afghanistan and Tajikistan have designated it as their official languages. It has 144 million speakers globally, making it the 13th or 14th most popularly spoken languages.</p>

<h3 style="color: #f51f8a">Philippine Translation</h3><p> Philippine or Filipino Language is based on Tagalog which is the native language spoken in Philippines. It serves as the national language of Philippines along with English.&nbsp;</p>

<h3 style="color: #f51f8a">Polish Translation</h3><p> Polish is spoken by around 38 million people in Poland, most of whom are mother tongue speakers. The global population of native Polish speakers is somewhere between 40 to 48 million. This makes Polish the most popular Slavic language after Russian.</p>

<h3 style="color: #f51f8a">Punjabi Translation</h3><p> Punjabi is a major language in India and Pakistan. Worldwide it is spoken by 88 million people, this places it among the 11th most spoken languages globally. Punjabi is also recognized as one of the official languages of India apart from serving as the official language for the Indian state of Punjab.&nbsp;</p>

      </div>







       <div class="tab-pane" id="s_tab">
        <h1></h1>
        <h3 style="color: #f51f8a">Quechua Translation</h3><p>Quechua refers to a family of Native American languages that share a common ancestor - Proto-Quechua. There are about 6 to 8 million speakers of Quechua languages. The language enjoys official recognition in Bolivia and Peru.&nbsp;</p>

      </div>




       <div class="tab-pane" id="t_tab">
        <h1></h1>

        <h3 style="color: #f51f8a">Russian Translation</h3><p> Russian is widely used across Eurasia. It has the largest number of native speakers in Europe, and is the most widely spoken among Slavic languages. At present it is also widely used outside Russia. More than a fourth of the global scientific literature is published in Russian. Russian is also one of the six official languages of the United Nations.</p>

 <h3 style="color: #f51f8a">Romanian Translation</h3><p> Romanian language is spoken by 24 to 28 million people. They are mostly found residing in Romania and Moldova. Romanian has been designated as the official language of Romania, Moldova and Vojvodina which is in Serbia. In Moldova it is known as the Moldovan language.</p>
      </div>





       <div class="tab-pane" id="u_tab">
        <h1></h1>

       <h3 style="color: #f51f8a">Spanish Translation</h3><p> There are over 400 million Spanish speakers all over the world. This places it among the second or third most widely spoken languages. Moreover, Spanish serves as the official language of about 21 countries.</p>

<h3 style="color: #f51f8a">Sami Translation</h3><p> Sami refers to a Uralic languages group. It is spoken by the Sami people who live mainly in Norway, Sweden, Finland and Russia (extreme southwest). There are approximately 20,000 speakers of the Sami language and it is used officially in selected Norwegian municipalities.</p>

<h3 style="color: #f51f8a">Samoan Translation</h3><p> Samoan language is spoken by the Samoa and American Samoa people. Most of the Samoan speakers can be found in Samoa Islands. New Zealand and Australia also have substantial populations of Samoan speakers followed by Hawaii, Tonga, Fiji and the USA. There are nearly 870,337 Samoa speakers worldwide.</p>

<h3 style="color: #f51f8a">Sanskrit Translation</h3><p> Sanskrit belongs to the Indo-Aryan family of languages. It is recognized as an official language of India and is distinguished as the language which has significantly influenced the development of a large number of languages especially in the Indian subcontinent. &nbsp;</p>

<h3 style="color: #f51f8a">Serbian Translation</h3><p> Serbian belongs to group of South Slavic languages and is mainly spoken in Serbia, Croatia, Bosnia, Herzegovina, Montenegro and by the Serbian diaspora. The words &ldquo;vampire&rdquo; and &ldquo;paprika&rdquo; which are very popular across various languages have their origins in Serbian.</p>

<h3 style="color: #f51f8a">Sesotho Translation</h3><p> Sesotho belongs to the Bantu family of languages. It is chiefly spoken in South Africa and is one of the official languages. Sesotho is also recognized as Lesotho&#39;s national language. It has around 4.2 million speakers most of whom live in Lesotho, South Africa, Zambia, Namibia and Botswana.&nbsp;</p>
<h3 style="color: #f51f8a">Setswana Translation</h3><p> Setswana is a part of the Bantu group of languages with about 3.5 million speakers. Botswana alone boasts around 1 million Setswana speakers and recognizes the language as a national language. Setswana is written with a Latin alphabet.</p>

<h3 style="color: #f51f8a">Shona Translation</h3><p> Shona language is spoken by about nine million people most of whom live in Zimbabwe. It serves as one of the two national languages of Zimbabwe. Besides Zimbabwe, Shona speakers are also found in Zambia, Mozambique and Botswana.</p>

<h3 style="color: #f51f8a">Simplified English Translation</h3><p> Simplified English is a controlled and standardized form of the English language. Documents prepared in Simplified English are clear to readers anywhere in the world. It makes the process of language translation easier, faster and more accurate.&nbsp;</p>

<h3 style="color: #f51f8a">Sindhi Translation</h3><p> Sindhi is the primary language used in the Sindh region of Pakistan. It also has a substantial number of speakers in India. Overall there are nearly 18 million Sindhi speakers in Pakistan and around 1 million in India. It is regarded as the official language of Sindh in Pakistan and one of the official languages of India.</p>

<h3 style="color: #f51f8a">SiSwati Translation</h3><p> SiSwati Language belongs to the Bantu branch of the Nguni languages family. It has approximately 1.5 million speakers living mostly in Swaziland and South Africa. Both Swaziland and South Africa regard it as one of their national languages.</p>

<h3 style="color: #f51f8a">Sinhalese Translation</h3><p> Sinhalese is the mother language of the major ethnic group of Sri Lanka, the Sinhalese. The language has around 19 million speakers worldwide of which 16 million are native speakers. Sinhalese serves as the official language of Sri Lanka.</p>
<h3 style="color: #f51f8a">Slovak Translation</h3><p> Slovak is spoken by over 5 million people in its native country. Apart from Slovak it is also spoken by large to small groups of people in various parts of the world. Slovak speakers can be found in reasonably large numbers in the Czech Republic and the United States. Ireland, Hungary, Romania, Northern Serbia, Croatia, Canada, Poland, Ukraine, Bulgaria, Austria, and Australia are some other countries where one can find Slovak speakers.</p>

<h3 style="color: #f51f8a">Slovenian Translation</h3><p>Slovenian is a part of the South Slavic languages family and apart from being the primary language used in Slovenia, it also serves as an official language of the European Union. Slovenian is spoken by over 2.4 million speakers around the world with the majority living in Slovenia.</p>
<h3 style="color: #f51f8a">Somali Translation</h3><p>Somali is the national language of Somalia and is used for all official work. It has roughly 10-16 million native speakers and around 500,000 second language speakers living in Somalia, Ethiopia, Kenya and Djibouti. The official Somali script uses a derivation of the Latin alphabet.</p>

<h3 style="color: #f51f8a">Sorbian Translation</h3><p> Sorbian is a part of the Slavic branch of Indo-European languages group. The language exists in two literary forms which are Upper Sorbian and Lower Sorbian. Upper Sorbian has significantly more speakers than Lower Sorbian.</p>

<h3 style="color: #f51f8a">Sundanese Translation</h3><p> Sundanese is the main language used in the western part of Java, it is spoken by nearly 27 million people. Sundanese speakers constitute about 15% of the Indonesian population. It is spoken in many dialects with the major ones being Banten, Bogor, Priangan and Cirebon.</p>
<h3 style="color: #f51f8a">Swedish Translation</h3><p> Swedish is the national language of Sweden and is used in spoken and written form by more than 9 million people. Out of these around 8 million are native users of the language. Though Swedish has many dialectical variations, Standard Swedish is most popular.</p>
<h3 style="color: #f51f8a">Swahili Translation</h3><p>Swahili is the major language among spoken along the Southeast African coast. It has around 5-10 million native speakers. It is spoken widely in Congo, Kenya, and Tanzania where it also serve as the national language.</p>

<h3 style="color: #f51f8a">Syriac Translation</h3><p> Syriac is an important historical language belonging to the Semitic family of languages; specifically it&#39;s a dialect of Middle Aramaic. Syriac was considered a major literary language from the 4th to 8th century and widely used all across Middle East.&nbsp;</p>
      </div>





       <div class="tab-pane" id="v_tab">
        <h1></h1>
      <h3 style="color: #f51f8a">Thai Translation</h3><p> Thailand provides great business opportunities being a much desired tourist destination. With the Thai language spoken in various dialects by about 65 million people in the country, the requirement for Thai translation services is growing increasingly. But Thai is a difficult language to master, especially for the westerners, so getting professional Thai translators can be a challenging task.</p>

<h3 style="color: #f51f8a">Tagalog Translation</h3><p> Tagalog speakers are chiefly found in Central Philippines. The language belongs to Austronesian group of languages. Tagalog speakers living in Philippines number over 64 million.</p>

<h3 style="color: #f51f8a">Tajik Translation</h3><p> Tajik, also known as Tajki is a modern dialect of the Persian language which is primarily used in Central Asia. It has approximately 4.4 million users living mainly in Afghanistan, Tajikistan, Russia, Uzbekistan, Kazakstan, Kyrgyzstan, Ukraine and Turkmenistan.</p>
<h3 style="color: #f51f8a">Tamazight Translation</h3><p> Tamazight or the Tarifit language is a Northern Berber language. The term Tamazight is also used to refer to Berber languages as a whole. The language is spoken by almost 4 million speakers, most of whom live in the Moroccan Rif area. Around 1 million of the Tamazight speakers live in Europe as immigrants.&nbsp;</p>

<h3 style="color: #f51f8a">Tamil Translation</h3><p> Tamil belongs to the Dravidian languages group, most of its speakers are found in the Indian subcontinent. The total worldwide population of Tamil speakers is nearly 52 million. Tamil is recognized as an official language in Sri Lanka, India and Singapore. India also recognizes it as a classical language.</p>
<h3 style="color: #f51f8a">Tatar Translation</h3><p> Tatar is a member of the Turkic languages group. It is spoken by almost 7 million people most of whom live in the Russian Republic of Tatarstan. Native speakers of the Tatar language are called Tatars. The written form of Tatar uses the Cyrillic alphabet; a number of different versions of Latin are also used.</p>
<h3 style="color: #f51f8a">Telugu Translation</h3><p> Telugu belongs to the Dravidian languages group and has about 74 million speakers around the world. However majority of its speakers reside in the Andhra Pradesh, an Indian state. The large population of Telugu speakers places it 14th among the most spoken languages of the world.&nbsp;</p>

<h3 style="color: #f51f8a">Tibetan Translation</h3><p>Tibetan is a group of Tibeto-Burman languages that are spoken mainly by Tibetan people found in the eastern part of Central Asia which includes the Tibetan Plateau. Tibetan speakers are also present in northern areas of the Indian subcontinent. Worldwide there are almost 6 million Tibetan speakers.&nbsp;</p>

<h3 style="color: #f51f8a">Tigrinya Translation</h3><p> Tigrinya is the most widely spoken language in Eritrea. It is third most frequently spoken language in Ethiopia. The Tigray-Tigrinya people who reside in Tigray which is in Northern Ethiopia are the mother tongue speakers of the language.</p>

<h3 style="color: #f51f8a">Tongan Translation</h3><p> Tongan is a Polynesian language with around 95,000 speakers most of whom reside in Tonga. The language also serves as the national language of Tonga. Tongan speakers are also found in Fiji, Niue, American Samoa, Vanuatu, New Zealand, Australia, Canada and the USA.&nbsp;</p>

<h3 style="color: #f51f8a">Tsonga Translation</h3><p> Tsonga is also called Xitsonga, it is the mother language of the Tsonga people who are natives of southern Africa. The language is spoken by a population of over 3 million. Most of the Tsonga speakers are found in South Africa&#39;s Limpopo Province, they are also found in Mozambique, Zimbabwe and Swaziland.&nbsp;</p>
<h3 style="color: #f51f8a">Turkish Translation</h3><p> The improving business relation between USA and Turkey is giving rise to increasing number of business opportunities every day. There are 60-67 million native speakers in Turkey and one of the most effective ways of easing communication between the Turk and the foreigners is through high quality Turkish translations.</p>

      </div>






       <div class="tab-pane" id="w_tab">
        <h1></h1>
        <h3 style="color: #f51f8a">Ukrainian Translation</h3><p> At present there are almost 50 million Ukrainians across the whole world. Around 37.5 million of these reside in Ukraine itself. The language is rising from an extended period of decline and offers considerable translation opportunities.</p>

<h3 style="color: #f51f8a">Urdu Translation</h3><p>Urdu language belongs to the Indo-Iranian branch under the Indo-European family of languages. It is recognized as the co-official and national language in Pakistan and as an official language in India. Urdu has around 60-80 million speakers worldwide which makes it the twentieth most spoken language in the world.&nbsp;</p>
<h3 style="color: #f51f8a">Uzbek Translation</h3><p> Uzbek has around 24.7 million speakers spread out across the CIS countries. Majority of the speakers are found in Uzbekistan where it is recognized as the official language. Uzbek has been written using the Latin, Arabic and Cyrillic alphabet in various periods of its history.</p>

      </div>






       <div class="tab-pane" id="x_tab">
        <h1></h1>
       <h3 style="color: #f51f8a">Vietnamese Translation</h3><p>Vietnamese, the official language of Vietnam is used as the first language by around 86% of the Vietnamese population. The figure increases when the approximately 3 million Vietnamese living overseas are taken into account. Most of the Vietnamese living overseas can be found residing in the USA. In fact, Vietnamese is the 7th most popularly spoken language in the USA.</p>

      </div>






       <div class="tab-pane" id="y_tab">
        <h1></h1>

        <h3 style="color: #f51f8a">Welsh Translation</h3><p> Welsh which is mainly spoken in Wales, England originated from the Brythonic branch of Celtic. One can find native Welsh speakers all over, however Great Britain, US, Canada, New Zealand and Australia have major Welsh speaking population.</p>

<h3 style="color: #f51f8a">Wolof Translation</h3><p> Wolof has approximately 7 million speakers living mostly in Senegal, France, Guinea, Gambia, Guinea-Bissau, Mali and Mauritania. It is widely spoken in Senegal by even non-ethnic speakers and recognized as a national language.&nbsp;</p>

      </div>






       <div class="tab-pane" id="z_tab">
        <h1></h1>
       <h3 style="color: #f51f8a">Xhosa Translation</h3><p> Xhosa language is spoken by nearly 7.9 million speakers. They live mostly in Orange Free State, Eastern Cape Province, Transkei and Ciskei in South Africa. South Africa also recognizes Xhosa as one of its official languages.&nbsp;</p>

      </div>




       <div class="tab-pane" id="aa_tab">
        <h1></h1>
               <h3 style="color: #f51f8a">Yiddish Translation</h3><p> Yiddish has its roots in Jewish and is primarily spoken by Orthodox Jewish communities in a number of countries of the world. It started developing from the 10th century from Ashkenazi culture.</p>
       <h3 style="color: #f51f8a">Yoruba Translation</h3><p> Yoruba is a part of a dialect continuum. It is spoken in West Africa by a population of 10 million speakers. Most of the Yoruba speakers are found in Nigeria, Togo and Benin. It is among the most popularly used native African languages.&nbsp;</p>

      </div>


       <div class="tab-pane" id="bb_tab">
        <h1></h1>
        <h3 style="color: #f51f8a">Zulu Translation</h3><p>  Zulu is the native language of the Zulu people. It has almost 10 million people most of whom live in South Africa. Zulu is also recognized as one of the official languages of South Africa. It is a tonal language but the tones are not indicated while writing.&nbsp;</p>

      </div>








       <!--<div class="tab-pane" id="cc_tab">
        <h1>Content of cc</h1>
      </div>-->





     <!-- <div class="tab-pane" id="c_tab">
        
        <ul class="nav nav-tabs">
          <li class="active"><a href="#first" data-toggle="tab">First</a></li>
          <li><a href="#second" data-toggle="tab">Second</a></li>
          <li><a href="#third" data-toggle="tab">Third</a></li>
        </ul>
        <div class="tab-content">
          <div id="first" class="tab-pane active">Content of first</div>
          <div id="second" class="tab-pane">Content of second</div>
          <div id="third" class="tab-pane">Content of third</div>
        </div>    
        
      </div>-->
    </div>
  </div>
</div>






<div class="footer section-space80">
        <!-- footer -->
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="footer-logo">
                        <!-- Footer Logo -->
                        <img src="{!!asset('images/logo2.png')!!}" alt="Borrow - Loan Company Website Templates" style="width: 300px;height: 130px"> </div>
                    <!-- /.Footer Logo -->
                </div>
                <div class="col-md-8 col-sm-8 col-xs-12">
                    <div class="col-md-5">
                        <h3 class="newsletter-title"></h3>
                    </div>
                    <div class="col-md-7">
                       
                        <!-- /.Newsletter Form -->
                    </div>
                    <!-- /.col-lg-6 -->
                </div>
            </div>
            <hr class="dark-line">
            <div class="row">
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="widget-text mt40">
                        <!-- widget text -->
                        <p>شركتنا تضمن لك ترجمة معتمدة بأحترافية و دقة و في نفس الوقت بأقل الأسعار</p>
                        <div class="row">
                            <div class="col-md-6 col-xs-6">
                                <p class="address-text"><span><i class="icon-placeholder-3 icon-1x"></i> </span>22 شارع خالد بن الوليد-شيراتون - الدور الثاني - شقة 22 -القاهرة-مصر</p>
                            </div>
                            <div class="col-md-6 col-xs-6">
                                <p class="call-text"><span><i class="icon-phone-call icon-1x"></i></span>+202 22685650</p>


                                <p class="call-text"><span><i class="icon-phone-call icon-1x"></i></span>+2 010 69977924</p>

                                  <p class="call-text"><span><i class=""></i></span>alboraq@alboraq.com.eg</p>
                            </div>
                        </div>
                    </div>
                    <!-- /.widget text -->
                </div>
                <div class="col-md-2 col-sm-4 col-xs-6">
                    <div class="widget-footer mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                           
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
                <div class="col-md-2 col-sm-4 col-xs-6">
                    <div class="widget-footer mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                            
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
                <div class="col-md-2 col-sm-4 col-xs-12">
                    <div class="widget-social mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                            <li><a href="https://www.facebook.com/al.boraq.5?ref=br_rs"><i class="fa fa-facebook"></i>Facebook</a></li>
                            <li><a href="https://plus.google.com/u/0/111389319385238976171"><i class="fa fa-google-plus"></i>Google Plus</a></li>
                            <li><a href="https://twitter.com/AlBoraq_ABTS"><i class="fa fa-twitter"></i>Twitter</a></li>
                            <li><a href="https://www.linkedin.com/in/al-boraq-translation-services-1a235658"><i class="fa fa-linkedin"></i>Linked In</a></li>
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
            </div>
        </div>
    </div>
    <!-- /.footer -->
    <div class="tiny-footer">
        <!-- tiny footer -->
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-6">
                    <p>© Copyright 2016 | البراق للترجمة </p>
                </div>
                <div class="col-md-6 col-sm-6 text-right col-xs-6">
                    <p></p>
                </div>
            </div>
        </div>
    </div>
    <!-- /.tiny footer -->
    <!-- back to top icon -->
    <a href="#0" class="cd-top" title="Go to top">Top</a>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="{!!asset('js/jquery.min.js')!!}"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="{!!asset('js/bootstrap.min.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/menumaker.js')!!}"></script>
    <!-- animsition -->
    <script type="text/javascript" src="{!!asset('js/animsition.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/animsition-script.js')!!}"></script>
    <!-- sticky header -->
    <script type="text/javascript" src="{!!asset('js/jquery.sticky.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/sticky-header.js')!!}"></script>
    <!-- slider script -->
    <script type="text/javascript" src="{!!asset('js/owl.carousel.min.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/slider-carousel.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/service-carousel.js')!!}"></script>
    <!-- Back to top script -->
    <script src="{!!asset('js/back-to-top.js')!!}" type="text/javascript"></script>



    
</body>


<!-- Mirrored from jituchauhan.com/borrow/borrow/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 20 Dec 2016 09:03:30 GMT -->
</html>
