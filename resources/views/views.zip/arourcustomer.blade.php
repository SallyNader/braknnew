   
<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from jituchauhan.com/borrow/borrow/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 20 Dec 2016 09:01:30 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="Alboraq is certified translation services online , we provides certified german translation services , certified french translation services , certified translation services birth certificate and other services, our website translation services cost is not high ,our online language translation services is the most professional translation services in egypt .">
    <meta name="keywords" content="Financial Website Template, Bootstrap Template, Loan Product, Personal Loan">
    <title>Best Translation Services Online | Certified Translation Services Online | Online Language Translation Services</title>
    <!-- Bootstrap -->
    <link href="{!!asset('css/bootstrap.min.css')!!}" rel="stylesheet">
    <link href="{!!asset('css/style.css')!!}" rel="stylesheet">
    <link href="{!!asset('css/font-awesome.min.css')!!}" rel="stylesheet">
    <link href="{!!asset('css/fontello.css')!!}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{!!asset('css/animsition.min.css')!!}">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700|Merriweather:300,300i,400,400i,700,700i" rel="stylesheet">
    <!-- owl Carousel Css -->
    <link href="{!!asset('css/owl.carousel.css')!!}" rel="stylesheet">
    <link href="{!!asset('css/owl.theme.css')!!}" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body class="animsition">
    <div class="collapse searchbar" id="searchbar">
        <div class="search-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search for...">
                            <span class="input-group-btn">
            <button class="btn btn-default" type="button">Go!</button>
            </span> </div>
                        <!-- /input-group -->
                    </div>
                    <!-- /.col-lg-6 -->
                </div>
            </div>
        </div>
    </div>
    <div class="top-bar">
        <!-- top-bar -->
        <div class="container">
            <div class="row" >
                <div class="col-md-4 hidden-xs hidden-sm">
                    <p class="mail-text" style="font-size:15px">مرحبا بكم في شركة البراق للترجمة المعتمدة</p>
                </div>
                <div class="col-md-8 col-sm-12 text-right col-xs-12"  style="font-size:13px">
                    <div class="top-nav"> <span class="top-text hidden-xs"><a href="{{url('arabic-about-contact-us')}}">لمعرفة مكان الشركة</a> </span> <span class="top-text"><a href="{{url('/')}}">English</a></span> <span class="top-text"><a href="{{url('/arabic')}}">عربي</a></span> </div>
                </div>
            </div>
        </div>
    </div>

    <style type="text/css">
.wi{


    font-weight: 500px
}
.c{


    font-size:19px 
}

.al{

    text-align: right;
}
</style>
    <!-- /.top-bar -->
    <div class="header">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-sm-12 col-xs-6" style="padding-left: 10px">
                    <!-- logo -->
                    <div class="logo"  >
                        <a href="{{url('/arabic')}}"><img   src="{!!asset('images/logo2.png')!!}" alt="Borrow - Loan Company Website Template" style="background-color: black" ></a>
                    </div>
                </div>
                <!-- logo -->
                 <div class="col-md-9 col-sm-12 col-xs-12" style="width:80%;float: right;margin-top:1px;hight:60px;margin-right: 2px">
                    <div id="navigation" >
                        <!-- navigation start-->
                        <ul >
                             <li><a style="font-size:19px" href="{{url('arabic-our-customers')}}" title="Contact us" class="animsition-link c">عملائنا</a></li>
                             <li>   <a style="font-size:19px" href="{{url('arabic-translator-jobs')}}" title="Personal Loan" class="animsition-link">انضم الينا</a></li>
                              <li><a style="font-size:19px" href="{{url('arabic-certifications')}}" title="Contact us" class="animsition-link">الاعتمادات</a></li>
                            <li><a style="font-size:19px" href="{{url('arabic-online-translation')}}" class="animsition-link">للترجمة أون لين</a>
                                        <!--<ul>
                                            <li><a href="shortcodes-tables.html" title="Table" class="animsition-link">Table</a></li>
                                            <li><a href="shortcodes-tabs.html" title="Tab" class="animsition-link">Tab</a></li>
                                            <li><a href="shortcodes-accordion.html" title="Accordion" class="animsition-link">Accordion</a></li>
                                            <li><a href="shortcodes-alert.html" title="Alert" class="animsition-link">Alert</a></li>
                                            <li><a href="shortcodes-button.html" title="Button" class="animsition-link">Button</a></li>
                                            <li><a href="shortcodes-column.html" title="Column" class="animsition-link">Column</a></li>
                                        </ul>-->
                                   
                            </li>
                             <li><a style="font-size:19px" href="{{url('languages')}}" class="animsition-link">اللغات</a>
                               <!-- <ul>
                                    <li><a href="compare-loan.html" title="Compare Loan" class="animsition-link">Compare Loan</a></li>
                                    <li><a href="loan-calculator.html" title="Loan Calculator" class="animsition-link">Loan Calculator</a></li>
                                    <li><a href="landing-page-car-loan.html" title="Loan Calculator" class="animsition-link">Car Loan 
                                     <small class="highlight">Landing Page</small>

                                     </a></li>
                                    <li><a href="landing-page-home-loan.html" title="Loan Calculator" class="animsition-link">Home Loan 
                                     <small class="highlight">Landing Page</small>

                                     </a></li>
                                    <li><a href="loan-calculator.html" title="Loan Calculator" class="animsition-link">Loan Calculator</a></li>
                                    <li><a href="faq.html" title="Faq" class="animsition-link">Faq page</a></li>
                                    <li><a href="testimonial.html" title="Testimonial" class="animsition-link">Testimonial</a></li>
                                    <li><a href="error.html" title="404 Error" class="animsition-link">404 Error</a></li>
                                    <li><a href="gallery-filter-2.html" class="animsition-link">Gallery</a>
                                        <ul>
                                            <li><a href="gallery-filter-2.html" title="Filterable Gallery 2 column" class="animsition-link">Filterable Gallery 2 column</a></li>
                                            <li><a href="gallery-filter-3.html" title="Filterable Gallery 3 column" class="animsition-link">Filterable Gallery 3 column</a></li>
                                            <li><a href="gallery-masonry.html" title="Masonry Gallery" class="animsition-link">Masonry Gallery</a></li>
                                            <li><a href="gallery-zoom.html" title="Zoom Gallery" class="animsition-link">Zoom Gallery</a></li>
                                        </ul>-->
                                    </li>
                             <li><a style="font-size:19px"  href="{{url('arabic-document-type-we-translate')}}" class="animsition-link">الوثائق </a>
                               <!-- <ul>
                                    <li><a href="blog-listing.html" title="Blog Listing" class="animsition-link">Blog Listing</a></li>
                                    <li><a href="blog-single.html" title="Blog Single" class="animsition-link">Blog Single</a></li>
                                    <li><a href="blog-two-column.html" title="Blog Two Column" class="animsition-link">Blog Two Column</a></li>
                                    <li><a href="blog-three-column.html" title="Blog Three Column" class="animsition-link">Blog Three Column</a></li>
                                </ul>-->
                            </li>

                            <li><a style="font-size:19px" class="animsition-link">خدمتنا</a>
                                <ul>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-document-proofreading-editing')}}" title="About us" class="animsition-link">مراجعة و تصحيح الوثائق</a></li>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-document-translation')}}" title="Team" class="animsition-link">ترجمة الوثائق</a></li>

<li><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-website-translation')}}" title="Team" class="animsition-link">ترجمة المواقع الألكترونية</a></li>
                      
                                    <li><a  style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-simultaneous-interpretation')}}" title="Team" class="animsition-link">ترجمة فورية</a></li>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-document-transcription')}}" title="Team" class="animsition-link">نسخ</a></li>
                                    <li style="height: 70px" ><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-video-audio-interpretation')}}" title="Team" class="animsition-link">ترجمة الفيديو و الملفات الصوتية</a></li>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-localization')}}" title="Team" class="animsition-link">التعريب</a></li>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-translation-service-content-development')}}" title="Team" class="animsition-link">تطوير و كتابة المحتوى</a></li>
                                </ul>
                            </li>
                                 <li><a style="font-size:19px;text-align: right" class="animsition-link">عن</a>
                                <ul>
                                    <li><a style="font-size:19px;text-align: right"  href="{{url('arabic-about-who-is-Alboraq')}}" title="Loan Image Listing" class="animsition-link">تعرف الى البراق</a></li>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-about-our-advantages')}}" title="Loan Icon Listing" class="animsition-link">مميزاتنا</a></li>
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-about-our-team')}}" title="Car Loan" class="animsition-link">خبراء الترجمة</a></li>
                                   
                                    <li><a style="font-size:19px;text-align: right" href="{{url('arabic-about-contact-us')}}" title="Home Loan" class="animsition-link">للتواصل معنا</a></li>
                                   
                                </ul>
                            </li>
                            <li class="active"><a style="font-size:19px" href="{{url('/arabic')}}" class="animsition-link">الصفحة الرئيسية</a>
                               <!-- <ul>
                                    <li><a href="index.html" title="Home page 1" class="animsition-link">Home page 1</a></li>
                                    <li><a href="index-1.html" title="Home page 2" class="animsition-link">Home page 2</a></li>
                                    <li><a href="index-2.html" title="Home page 3" class="animsition-link">Home page 3</a></li>
                                </ul>-->
                            </li>
                       
                         
                           
                                    
                          
                        


                            
                             





                        </ul>
                    </div>
                    <!-- /.navigation start-->
                </div>
                <!--
                <div class="col-md-1 hidden-sm">
          
                    <div class="search-nav"> <a class="search-btn" role="button" data-toggle="collapse" href="#searchbar" aria-expanded="false"><i class="fa fa-search"></i></a> </div>
                </div>-->
                <!-- /.search start-->
            </div>
        </div>
    </div>

<!--    <div class="col-md-1 hidden-sm">
                    
                    <div class="search-nav"> <a class="search-btn" role="button" data-toggle="collapse" href="#searchbar" aria-expanded="false"><i class="fa fa-search"></i></a> </div>
                </div> -->
                <!-- /.search start-->
            </div>
        </div>
    </div>
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-breadcrumb">
                        <ol class="breadcrumb">
                            <li><a href="{{url('/arabic')}}" class="c">الصفحة الرئيسية</a></li>
                            <li class="active c">عملائنا</li>
                        </ol>
                    </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="bg-white pinside30">
                        <div class="row">
                            <div class="col-md-4 col-sm-5">
                                <h1 class="page-title">عملائنا</h1>
                            </div>
                           <!-- <div class="col-md-8 col-sm-7">
                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="btn-action"> <a href="#" class="btn btn-default">How To Apply</a> </div>
                                    </div>
                                </div>
                            </div>-->
                        </div>
                    </div>
                       <div class="sub-nav" id="sub-nav">
                        <ul class="nav nav-justified">
                            <li><a href="{{url('arabic-about-who-is-Alboraq')}}" class="c" style="font-size:19px">تعرف على البراق</a></li>
                            <li><a href="{{url('arabic-about-our-team')}}" class="c" style="font-size:19px">تعرف على خبرائنا</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class=" ">
        <!-- content start -->
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="wrapper-content bg-white pinside40">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="mb60">
                                    <p class="lead al">ترجمتنا المعتمدة هي أختيار أكثر من 500 شركة من كبار الشركات و المصالح الحكومية و المنظمات الغير هادفة للربح </p>
                                </div>
                            </div>
                        </div><div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0"></h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer10.jpg')!!}" alt="Borrow - Loan Company Website Template"> <h4>النساجون الشرقيون</h4></div>
                                      <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer1.jpg')!!}" alt="Borrow - Loan Company Website Template"> 
                                    <h4>ASEC Automation</h4> </div>
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer2.jpg')!!}" alt="Borrow - Loan Company Website Template"> 
                                    <h4 class="mb0">BG Group</h4></div>
                                      <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer3.jpg')!!}" alt="Borrow - Loan Company Website Template">   <h4 class="mb0">Coca Cola</h4></div>
                                        <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer4.jpg')!!}" alt="Borrow - Loan Company Website Template">  <h4 class="mb0">Dairy Queen</h4></div>
                                           <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer5.jpg')!!}" alt="Borrow - Loan Company Website Template">                                 <h4 class="mb0">Dana Gas</h4>
</div>

                                   <!--  <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px"> تعد النساجون الشرقيون من كبرى مصنعي السجاد والموكيت ومستلزمات الإنتاج والسلع الوسيطة. وتمتلك النساجون الشرقيون شبكة مصانع عملاقة في ثلاث دول، وتقوم كذلك بتصدير منتاجاتها لأكثر من 130 دولة حول العالم</p> </div>
                                    </div>-->
                                </div>

                            </div>
                        </div>

                        <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0"></h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                   <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer6.jpg')!!}" alt="Borrow - Loan Company Website Template">  <h4 class="mb0">El Zahed Group </h4></div>

                                   <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer7.jpg')!!}" alt="Borrow - Loan Company Website Template"><h4 class="mb0">Hess Corporation</h4> </div>
                                   <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer8.jpg')!!}" alt="Borrow - Loan Company Website Template"> <h4 class="mb0">ITSC</h4> </div>
                                   <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer9.jpg')!!}" alt="Borrow - Loan Company Website Template">
                                   <h4 class="mb0">Manufacturing & Technology Center</h4> </div>
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer11.jpg')!!}" alt="Borrow - Loan Company Website Template">   <h4 class="mb0">Petro Alam</h4></div>
                                     <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer12.jpg')!!}" alt="Borrow - Loan Company Website Template">                                <h4 class="mb0">Promax Community</h4>
 </div>
                                    
                                  <!--  <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px">Backed with 15years of experience, ASEC Automation is now recognized as source of updated technology, covering a wide range of industries, especially cement industry.</p> </div>
                                    </div>-->
                               
                                    </div>
                                
                            </div>
                        </div>
                        <!-- <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">BG Group</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer2.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px">BG Group began as the independent start-up company Queensland Gas Company Limited, which listed on the Australian Securities Exchange in 1999.</p> </div>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                        <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">Coca Cola</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer3.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                   <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px">A global leader in the beverage industry, the Coca-Cola company offers hundreds of brands, including soft drinks, fruit juices, sports drinks and other beverages.</p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">Dairy Queen</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer4.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px"> International Dairy Queen first developed in 1938 by Douds, Iowa-born John Fremont "Grandpa" McCullough (1871‒1963).</p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">Dana Gas</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer5.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px">Dana Gas is the Middle East’s leading private sector natural gas company producing some63 ,900 barrels of oil equivalen​​​t per day of oil, gas and natural gas liquids from its operations in Egypt.</p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                             <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">El Zahed Group </h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer6.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                   <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px"> El Zahed Group was established on the first of April in 1995 and has over 17 years experience of distributing engine and industrial lubricants backed up by a reputation for delivering quality products and consumer satisfaction. </p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                             <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">Hess Corporation</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer7.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px"> Hess, a leading producer with a premier acreage position in North Dakota’s Bakken shale formation.</p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                             <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">ITSC</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer8.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px"> Established in 1998, ITSC is an S.A.E. company specializing in developing Business-to-Business (B2B) IT solutions. ITSC has succeeded in
                                             becoming the first Egyptian company to acquire a commercial VAN license, facilitating Electronic
                                              Data Interchange (EDI) via its country switch.</p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                             <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">Manufacturing & Technology Center</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer9.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                     <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px"> MTC has established a flexible core platform of facilities in Canada and the USA to specifically address the needs of the industry.</p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                             
                             <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">Petro Alam</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer11.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                     <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px"> The Alam el Shawish block was awarded to Vegas through an EGPC licensing round. Vegas was the sole participant and operator upon award in 2005.</p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                             <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">Promax Community</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer12.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px"> Promax has a solid financial base, from which to take advantage of the prime market conditions, with significant assets, substantial internal capital and confidence.</p> </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->

                             <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0"></h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer13.jpg')!!}" alt="Borrow - Loan Company Website Template" > 
                                     <h4 class="mb0">RASHPETCO</h4></div>
                                     <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer14.jpg')!!}" alt="Borrow - Loan Company Website Template">    <h4 class="mb0">SANOFI AVENTIS</h4> </div>

                                     <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer15.jpg')!!}" alt="Borrow - Loan Company Website Template">  <h4 class="mb0">Schlumberger</h4></div>
                                 <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer16.jpg')!!}" alt="Borrow - Loan Company Website Template">  <h4 class="mb0">Siemens</h4></div>
                                   <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer17.jpg')!!}" alt="Borrow - Loan Company Website Template"><h4 class="mb0">SkyNet</h4> </div>
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer18.jpg')!!}" alt="Borrow - Loan Company Website Template"><h4 class="mb0">Sedra</h4> </div>
                                </div>
                            </div>
                        </div>
<!--
                             <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">SANOFI AVENTIS</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer14.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                     <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px"> Sanofi is the heir to a long history that includes some of the major scientific advances of the nineteenth and twentieth centuries, and the reputations of major industrial laboratories in the development of chemistry, pharmacy and medicine.

</p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                                                <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">Schlumberger</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer15.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                     <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px">It took until 1920 for Conrad Schlumberger to publish the results of the experimental surface resistivity measurements he had carried out since 1911.</p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                                                <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">Siemens</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer16.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px"> Siemens  is a German conglomerate company headquartered in Berlin and Munich and the largest manufacturing and electronics company in Europe with branch offices abroad.</p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                                                <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">SkyNet</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer17.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px"> The SkyNet Worldwide Express network stretches across 7 continents, providing the Global business community with fast, reliable and secure Express delivery services to over 209 countries and territories Worldwide. </p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                                                <div class="compare-block mb30">
                            <div class="compare-title bg-primary pinside20">
                                <h3 class="mb0">Sedra</h3>
                            </div>
                            <div class="compare-row outline pinside30">
                                <div class="row">
                                    <div class="col-md-2 col-sm-12 col-xs-12"> <img src="{!!asset('images/our-customer18.jpg')!!}" alt="Borrow - Loan Company Website Template"> </div>
                                    <div class="col-md-2 col-sm-2 col-xs-6" >
                                        <div class="text-center" style="padding-left:60px;width:600px;text-align: justify;    text-justify: inter-word;">
                                            <h3 class="rate"></h3>
                                            <p style="padding-left:220px; word-wrap: break-word;padding-top:20px"> Founded in 2004 by our director, Natra Saeed Abdulla, Sedra property managments was the first International Real Estate Company to begin operations in Egypt. We have pioneered a new standard of excellence in the Real Estate field and are committed to providing a service that is second to none.</p> </div>
                                    </div>
                                </div>
                            </div>
                        </div>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.content end -->

    




 <div class="footer section-space80">
        <!-- footer -->
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="footer-logo">
                        <!-- Footer Logo -->
                        <img src="{!!asset('images/logo2.png')!!}" alt="Borrow - Loan Company Website Templates" style="width: 300px;height: 130px"> </div>
                    <!-- /.Footer Logo -->
                </div>
                <div class="col-md-8 col-sm-8 col-xs-12">
                    <div class="col-md-5">
                        <h3 class="newsletter-title"></h3>
                    </div>
                    <div class="col-md-7">
                       
                        <!-- /.Newsletter Form -->
                    </div>
                    <!-- /.col-lg-6 -->
                </div>
            </div>
            <hr class="dark-line">
            <div class="row">
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="widget-text mt40">
                        <!-- widget text -->
                        <p>شركتنا تضمن لك ترجمة معتمدة بأحترافية و دقة و في نفس الوقت بأقل الأسعار</p>
                        <div class="row">
                            <div class="col-md-6 col-xs-6">
                                <p class="address-text"><span><i class="icon-placeholder-3 icon-1x"></i> </span>22 شارع خالد بن الوليد-شيراتون - الدور الثاني - شقة 22 -القاهرة-مصر</p>
                            </div>
                            <div class="col-md-6 col-xs-6">
                                <p class="call-text"><span><i class="icon-phone-call icon-1x"></i></span>+202 22685650</p>


                                <p class="call-text"><span><i class="icon-phone-call icon-1x"></i></span>+2 010 69977924</p>

                                  <p class="call-text"><span><i class=""></i></span>alboraq@alboraq.com.eg</p>
                            </div>
                        </div>
                    </div>
                    <!-- /.widget text -->
                </div>
                <div class="col-md-2 col-sm-4 col-xs-6">
                    <div class="widget-footer mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                           
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
                <div class="col-md-2 col-sm-4 col-xs-6">
                    <div class="widget-footer mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                            
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
                <div class="col-md-2 col-sm-4 col-xs-12">
                    <div class="widget-social mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                            <li><a href="https://www.facebook.com/al.boraq.5?ref=br_rs"><i class="fa fa-facebook"></i>Facebook</a></li>
                            <li><a href="https://plus.google.com/u/0/111389319385238976171"><i class="fa fa-google-plus"></i>Google Plus</a></li>
                            <li><a href="https://twitter.com/AlBoraq_ABTS"><i class="fa fa-twitter"></i>Twitter</a></li>
                            <li><a href="https://www.linkedin.com/in/al-boraq-translation-services-1a235658"><i class="fa fa-linkedin"></i>Linked In</a></li>
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
            </div>
        </div>
    </div>
    <!-- /.footer -->
    <div class="tiny-footer">
        <!-- tiny footer -->
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-6">
                    <p>© Copyright 2016 | البراق للترجمة </p>
                </div>
                <div class="col-md-6 col-sm-6 text-right col-xs-6">
                    <p></p>
                </div>
            </div>
        </div>
    </div>
    <!-- /.tiny footer -->
    <!-- back to top icon -->
    <a href="#0" class="cd-top" title="Go to top">Top</a>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="{!!asset('js/jquery.min.js')!!}"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="{!!asset('js/bootstrap.min.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/menumaker.js')!!}"></script>
    <!-- animsition -->
    <script type="text/javascript" src="{!!asset('js/animsition.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/animsition-script.js')!!}"></script>
    <!-- sticky header -->
    <script type="text/javascript" src="{!!asset('js/jquery.sticky.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/sticky-header.js')!!}"></script>
    <!-- slider script -->
    <script type="text/javascript" src="{!!asset('js/owl.carousel.min.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/slider-carousel.js')!!}"></script>
    <script type="text/javascript" src="{!!asset('js/service-carousel.js')!!}"></script>
    <!-- Back to top script -->
    <script src="{!!asset('js/back-to-top.js')!!}" type="text/javascript"></script>



    
</body>


<!-- Mirrored from jituchauhan.com/borrow/borrow/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 20 Dec 2016 09:03:30 GMT -->
</html>
